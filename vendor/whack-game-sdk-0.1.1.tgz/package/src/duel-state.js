const isSlot = (slot) => slot === 0 || slot === 1;
const isScore = (score) => typeof score === "string" || Number.isFinite(score);

function normalizePlayers(players) {
  if (!Array.isArray(players) || players.length !== 2) {
    throw new TypeError("A duel requires exactly two player slots");
  }
  return Array.from(players, (player) => {
    if (player === null) return null;
    if (typeof player?.id !== "string" || !player.id.trim() ||
        (player.name !== undefined && typeof player.name !== "string") ||
        (player.avatarUrl !== undefined && typeof player.avatarUrl !== "string") ||
        (player.ready !== undefined && typeof player.ready !== "boolean") ||
        (player.isHost !== undefined && typeof player.isHost !== "boolean")) {
      throw new TypeError("A player requires an id and may have name, avatarUrl, ready and isHost");
    }
    const { id, name, avatarUrl, ready = false, isHost = false } = player;
    const normalized = { id, avatarUrl, ready, isHost };
    if (name !== undefined && name.trim()) normalized.name = name.trim();
    return normalized;
  });
}

export function normalizeLobbyState({
  players, localSlot = 0, isHost = true, canJoin = true, canReady = false, ready = false, canStart = false,
}) {
  if (!isSlot(localSlot)) throw new TypeError("localSlot must be 0 or 1");
  if ([isHost, canJoin, canReady, ready, canStart].some((value) => typeof value !== "boolean")) {
    throw new TypeError("Lobby permissions and ready state must be booleans");
  }
  return { players: normalizePlayers(players), localSlot, isHost, canJoin, canReady, ready, canStart };
}

export function normalizeSettlement(payload, round) {
  const { status, winnerSlot } = payload;
  const { localSlot } = round;
  const players = payload.players === undefined ? round.players : normalizePlayers(payload.players);
  const scores = [undefined, undefined];
  if (status === "waiting") {
    if (!isScore(payload.score)) throw new TypeError("A waiting result requires the local player's score");
    scores[localSlot] = payload.score;
  } else if (status === "finished") {
    if (!Array.isArray(payload.scores) || payload.scores.length !== 2 ||
        !isScore(payload.scores[0]) || !isScore(payload.scores[1])) {
      throw new TypeError("A finished result requires two scores");
    }
    if (winnerSlot !== undefined && winnerSlot !== null && !isSlot(winnerSlot)) {
      throw new TypeError("winnerSlot must be 0, 1 or null");
    }
    scores[0] = payload.scores[0];
    scores[1] = payload.scores[1];
  } else if (status !== "closed") {
    throw new TypeError("Unknown duel settlement status");
  }
  return { status, players, localSlot, scores, winnerSlot: status === "finished" ? winnerSlot : undefined };
}
