import { normalizeLobbyState, normalizeSettlement } from "./duel-state.js";
import {
  applyCommunityRoom, applyRoomApplyEvent, applyRoomUnapplyEvent, communityLobbyState,
  communitySettlementFromResult, fetchCommunityRoom, matchesCommunityRoomEvent, resolveCommunityWsUrl,
  primaryResultRule, resultRuleUnit, RoomConnectionError, startCommunityRoom, submitCommunityResult,
} from "./community-room.js";
import { createCommunityWimClient } from "./community-wim.js";

const controls = new Set(["game.join", "round.start", "round.finish", "round.forceEnd", "round.result"]);
const hasId = (value) => typeof value === "string" && value.trim().length > 0;

function validResult(payload) {
  return payload != null &&
    typeof payload === "object" &&
    typeof payload.title === "string" &&
    (payload.message === undefined || typeof payload.message === "string") &&
    (payload.rows === undefined || (Array.isArray(payload.rows) && payload.rows.every((row) =>
      typeof row?.label === "string" &&
      (typeof row.value === "string" || Number.isFinite(row.value)))));
}

export function createSession({
  gameId, game, transport, view, lobby = {}, settlement = {}, appUser, onAppUser, onGuestRequired, onMessage, onError,
  room, roomWsUrl, startupError, webSocketImpl, trafficLog,
}) {
  const startedRounds = new Set();
  let phase = "idle";
  let round;
  let connection;
  let pendingLobbyAction;
  let lobbyState = normalizeLobbyState({ players: [null, null], isHost: !room });
  let roomInfo = null;
  let roomRequest;
  let scoreRequest;
  let roomAuthToken = null;
  let roomImToken = null;
  let localPlayerId = null;
  let localProfile = null;
  let appUserTimer;
  let roomReleased = false;
  let wimClient;
  let wimHasJoined = false;

  function updateLobby(state) {
    if (phase === "destroyed") return false;
    lobbyState = normalizeLobbyState(state);
    view.updateLobby(lobbyState);
    return true;
  }

  function applyRoomInfo(info, playerId) {
    if (roomInfo?.status >= 3 && info.status < roomInfo.status) return;
    updateLobby(communityLobbyState(info, playerId));
    view.updateRoomBranding?.({
      title: typeof info.game_info?.game_name === "string" ? info.game_info.game_name : undefined,
      iconUrl: typeof info.game_info?.game_icon === "string" ? info.game_info.game_icon : undefined,
      rules: typeof info.game_rule === "string" ? info.game_rule : undefined,
    });
    roomInfo = info;
  }

  async function runRoomRequest(task, timeoutMessage) {
    roomRequest?.abort();
    const request = new AbortController();
    roomRequest = request;
    const timeout = setTimeout(() => request.abort(new RoomConnectionError(timeoutMessage)), 10000);
    try {
      return await task(request.signal);
    } catch (error) {
      if (request.signal.aborted) throw request.signal.reason;
      throw error;
    } finally {
      clearTimeout(timeout);
      if (roomRequest === request) roomRequest = undefined;
    }
  }

  async function refreshRoomSilently() {
    if (!room || !roomAuthToken || !localPlayerId || roomReleased || phase === "destroyed") return;
    try {
      const info = await runRoomRequest(
        (signal) => fetchCommunityRoom(room, roomAuthToken, localPlayerId, signal, trafficLog),
        "房间信息刷新超时。",
      );
      if (phase === "destroyed" || roomReleased) return;
      applyRoomInfo(info, localPlayerId);
    } catch (error) {
      if (phase !== "destroyed" && !roomReleased && error?.name !== "AbortError") roomConnectionFailed(error, "fetchRoomInfo");
    }
  }

  function handleCommunityWimEvent({ event, data }) {
    if (phase === "destroyed" || roomReleased) return;
    if (event === "game_room_apply") {
      if (!roomInfo) return;
      const nextInfo = applyRoomApplyEvent(roomInfo, data);
      if (nextInfo !== roomInfo) {
        roomInfo = nextInfo;
        if (phase === "lobby") updateLobby(communityLobbyState(roomInfo, localPlayerId));
      }
      return;
    }
    if (event === "game_room_unapply") {
      if (!roomInfo) return;
      const nextInfo = applyRoomUnapplyEvent(roomInfo, data);
      if (nextInfo !== roomInfo) {
        roomInfo = nextInfo;
        if (phase === "lobby") updateLobby(communityLobbyState(roomInfo, localPlayerId));
      }
      return;
    }
    if (event === "game_start") {
      if (phase !== "lobby" || !matchesCommunityRoomEvent(room, data) ||
          startedRounds.has(room.chatRoomId) || roomInfo?.status >= 250) return;
      const isParticipant = lobbyState.players.some((player) => player?.id === localPlayerId);
      if (roomInfo) {
        roomInfo = { ...roomInfo, status: 3 };
        updateLobby(communityLobbyState(roomInfo, localPlayerId));
      }
      if (!isParticipant) {
        startedRounds.add(room.chatRoomId);
        view.showLobbyStarted?.();
        return;
      }
      startRound({
        roundId: room.chatRoomId,
        payload: {
          groupId: room.groupId,
          gameId: room.gameId,
          chatRoomId: room.chatRoomId,
          status: 3,
          roomInfo,
          resultRules: roomInfo?.result_rules ?? [],
        },
      });
      return;
    }
    if (event === "whackgroup:game_pk_result") {
      if (!matchesCommunityRoomEvent(room, data)) return;
      if (roomInfo) {
        roomInfo = { ...roomInfo, status: Number.isInteger(data.status) ? data.status : 250 };
        updateLobby(communityLobbyState(roomInfo, localPlayerId));
      }
      if (phase === "playing" || phase === "waiting") {
        applySettlement(communitySettlementFromResult(data, round, roomInfo?.result_rules));
      }
      return;
    }
    try {
      onMessage?.({
        type: event,
        gameId,
        roundId: phase === "playing" ? round?.id : undefined,
        payload: data,
      });
    } catch (error) {
      report(error, "onMessage");
    }
  }

  function handleCommunityRoomReleased() {
    if (phase === "destroyed" || roomReleased) return;
    roomReleased = true;
    roomRequest?.abort();
    clearLobbyAction();
    if (roomInfo) {
      roomInfo = { ...roomInfo, status: 254, locked: true };
      updateLobby(communityLobbyState(roomInfo, localPlayerId));
    }
    if (phase === "lobby") {
      view.setLobbyError("房间已释放。");
    } else if (phase === "playing" || phase === "waiting") {
      applySettlement({
        status: "closed",
        players: round.players,
        localSlot: round.localSlot,
        scores: [undefined, undefined],
      });
    }
  }

  function connectCommunityWim() {
    if (transport || !room || roomReleased || wimClient || phase === "destroyed") return;
    if (!roomImToken) {
      view.setLobbyBusy(true);
      view.setConnection("closed", false);
      roomConnectionFailed(new Error("缺少聊天室登录凭证，请从 App 重新进入。"), "connectWim");
      return;
    }
    try {
      const wsUrl = roomWsUrl ?? resolveCommunityWsUrl(room);
      wimClient = createCommunityWimClient({
        url: wsUrl,
        roomId: room.chatRoomId,
        playerId: localPlayerId,
        token: roomImToken,
        WebSocketImpl: webSocketImpl,
        log: trafficLog,
        onStatus(status, error) {
          if (phase === "destroyed") return;
          if (status === "closed" && (roomReleased || wimClient?.released)) {
            view.setConnection("closed", false);
            return;
          }
          view.setConnection(status);
          if (phase === "lobby") view.setLobbyBusy(status !== "open");
          if (error) roomConnectionFailed(error, "connectWim");
          if (status === "open") view.clearConnectionFailure?.();
        },
        onJoined() {
          if (phase === "destroyed" || roomReleased) return;
          if (wimHasJoined) void refreshRoomSilently();
          else wimHasJoined = true;
        },
        onEvent: handleCommunityWimEvent,
        onReleased: handleCommunityRoomReleased,
        onError(error) {
          if (phase === "destroyed") return;
          trafficLog?.write("WIM 消息错误", { message: error.message });
          report(error, "wim");
        },
      });
      wimClient.connect();
    } catch (error) {
      view.setLobbyBusy(true);
      view.setConnection("closed", false);
      roomConnectionFailed(error, "connectWim");
    }
  }

  async function loadRoom(profile, authToken, imToken) {
    localProfile = profile;
    localPlayerId = profile.id;
    roomAuthToken = authToken || null;
    roomImToken = imToken || null;
    if (!transport) view.setConnection("connecting");
    try {
      const info = await runRoomRequest(
        (signal) => fetchCommunityRoom(room, authToken, profile.id, signal, trafficLog),
        "房间信息请求超时，请重新打开游戏。",
      );
      if (phase === "destroyed" || roomReleased) return;
      applyRoomInfo(info, profile.id);
      view.setLobbyBusy(false);
      if (info.status === 254 || info.status === 255) {
        roomReleased = true;
      } else if (info.status !== 250) {
        connectCommunityWim();
      }
      if (!transport && (roomReleased || info.status === 250)) view.setConnection("open");
    } catch (error) {
      if (phase === "destroyed" || roomReleased || error?.name === "AbortError") return;
      if (!transport) view.setConnection("closed", Boolean(authToken));
      roomConnectionFailed(error, "fetchRoomInfo");
    }
  }

  async function communityLobbyAction(action) {
    if (!roomInfo || !localPlayerId || roomReleased) return;
    if (action.type === "join") {
      if (!lobbyState.canJoin || (action.slot !== 0 && action.slot !== 1) || lobbyState.players[action.slot]) return;
      await runRoomRequest(
        (signal) => applyCommunityRoom(room, roomAuthToken, {
          index: action.slot + 1, status: 1, isNpc: false,
        }, signal, trafficLog),
        "报名请求超时，请重试。",
      );
      if (phase !== "lobby" || roomReleased) return;
      if (wimClient?.joined) {
        roomInfo = applyRoomApplyEvent(roomInfo, {
          user: {
            user_id: localPlayerId,
            nick_name: localProfile?.nickname || undefined,
            head_img: localProfile?.avatarUrl || undefined,
          },
          index: action.slot + 1,
          is_npc: false,
        });
        updateLobby(communityLobbyState(roomInfo, localPlayerId));
        return;
      }
    } else if (action.type === "ready") {
      const seatedSlot = lobbyState.players.findIndex((player) => player?.id === localPlayerId);
      if (seatedSlot === -1 || !lobbyState.canReady) return;
      if (lobbyState.isHost && lobbyState.ready) return;
      const nextStatus = lobbyState.ready ? 0 : 1;
      await runRoomRequest(
        (signal) => applyCommunityRoom(room, roomAuthToken, {
          index: seatedSlot + 1, status: nextStatus, isNpc: false,
        }, signal, trafficLog),
        nextStatus === 1 ? "报名请求超时，请重试。" : "取消报名请求超时，请重试。",
      );
      if (phase !== "lobby" || roomReleased) return;
      if (wimClient?.joined) {
        roomInfo = nextStatus === 0
          ? applyRoomUnapplyEvent(roomInfo, { user: { user_id: localPlayerId } })
          : applyRoomApplyEvent(roomInfo, {
            user: {
              user_id: localPlayerId,
              nick_name: localProfile?.nickname || undefined,
              head_img: localProfile?.avatarUrl || undefined,
            },
            index: seatedSlot + 1,
            is_npc: false,
          });
        updateLobby(communityLobbyState(roomInfo, localPlayerId));
        return;
      }
    } else if (action.type === "start") {
      if (!lobbyState.isHost || !lobbyState.canStart || !lobbyState.players.every(Boolean)) return;
      await runRoomRequest(
        (signal) => startCommunityRoom(room, roomAuthToken, signal, trafficLog),
        "开始游戏请求超时，请重试。",
      );
      if (phase !== "lobby" || roomReleased || wimClient?.joined) return;
    } else {
      return;
    }
    if (phase !== "lobby" || roomReleased) return;
    const info = await runRoomRequest(
      (signal) => fetchCommunityRoom(room, roomAuthToken, localPlayerId, signal, trafficLog),
      "房间信息刷新超时，请稍后重试。",
    );
    if (phase === "lobby" && !roomReleased) applyRoomInfo(info, localPlayerId);
  }

  async function notifyAppUser(profile) {
    try {
      await onAppUser?.(profile);
    } catch (error) {
      report(error, "onAppUser");
    }
  }

  function clearLobbyAction() {
    if (!pendingLobbyAction) return;
    pendingLobbyAction = undefined;
    view.setLobbyBusy(Boolean(wimClient && !wimClient.joined));
  }

  async function lobbyAction(action) {
    if (phase !== "lobby") return;
    if (action.type === "inspectAppUser") {
      const result = appUser?.inspect?.();
      if (result) trafficLog?.write(result.ok ? "JSQueryInitInfo 调用成功" : "JSQueryInitInfo 调用失败", result);
      return;
    }
    const windowAction = action.type === "minimize" || action.type === "exit";
    const useCommunityHandler = !windowAction && !lobby.onAction && Boolean(room);
    const handler = windowAction
      ? (action.type === "minimize" ? lobby.onMinimize : lobby.onExit)
      : (lobby.onAction ?? (room ? communityLobbyAction : undefined));
    if (!handler || (!windowAction && (pendingLobbyAction || (room && (!roomInfo || roomReleased))))) return;
    if (useCommunityHandler && wimClient && !wimClient.joined) return;
    if (action.type === "start" && (!lobbyState.isHost || !lobbyState.players.every(Boolean))) return;
    if (action.type === "ready" && lobbyState.isHost && lobbyState.ready && !lobbyState.canReady) return;

    const request = windowAction ? undefined : {};
    if (request) {
      pendingLobbyAction = request;
      view.setLobbyBusy(true);
    }
    view.setLobbyError("");
    try {
      await handler(action);
    } catch (error) {
      if (useCommunityHandler && error?.name === "AbortError") return;
      if (phase === "lobby" && (!request || pendingLobbyAction === request)) {
        if (useCommunityHandler && error instanceof RoomConnectionError) {
          roomConnectionFailed(error, "lobbyAction");
          return;
        }
        const message = useCommunityHandler && error?.constructor === Error && error.message
          ? error.message
          : "大厅操作失败，请重试。";
        if (useCommunityHandler) trafficLog?.write("HTTP 请求失败", { message });
        view.setLobbyError(message);
      }
      report(error, "lobbyAction");
    } finally {
      if (request && pendingLobbyAction === request) clearLobbyAction();
    }
  }

  function report(error, operation) {
    try {
      onError?.(error, operation);
    } catch (callbackError) {
      console.error(callbackError);
    }
  }

  function roomConnectionFailed(error, operation) {
    trafficLog?.write("服务器连接失败", { operation, message: error?.message ?? "未知错误" });
    view.showConnectionFailure?.();
    report(error, operation);
  }

  function send(type, payload, roundId) {
    if (!hasId(type) || controls.has(type)) {
      throw new TypeError("A custom message type is required");
    }
    if (connection?.status !== "open") {
      throw new Error("The SDK is disconnected");
    }
    const message = { type, gameId, roundId, payload };
    trafficLog?.write("通信发送", message);
    transport.send(message);
  }

  function sendFinish() {
    if (phase !== "waiting" || !round.finish || connection?.status !== "open" ||
        round.lastFinishConnection === connection) {
      return;
    }
    const attempt = connection;
    round.lastFinishConnection = attempt;
    try {
      const message = { type: "round.finish", gameId, roundId: round.id, payload: round.finish };
      trafficLog?.write("通信发送", message);
      transport.send(message);
    } catch (error) {
      if (connection === attempt && phase === "waiting" && round.finish) {
        attempt.finishFailed = true;
        view.setError("结束消息发送失败。");
        view.setConnection(connection.status, true);
      }
      report(error, "sendFinish");
    }
  }

  async function sendCommunityFinish(refreshRules = false) {
    const current = round;
    const pending = current?.communityFinish;
    const waiting = () => round === current && phase === "waiting" && !roomReleased;
    if (!waiting() || !pending || scoreRequest) return;
    const request = new AbortController();
    scoreRequest = request;
    const timeout = setTimeout(() => request.abort(), 10000);
    view.setCommunitySubmission?.("submitting");
    try {
      let rules = roomInfo?.result_rules;
      if (refreshRules && (!Array.isArray(rules) || !rules.length)) {
        const info = await fetchCommunityRoom(room, roomAuthToken, localPlayerId, request.signal, trafficLog);
        if (!waiting()) return;
        roomInfo = info;
        rules = info.result_rules;
      }
      await submitCommunityResult(room, roomAuthToken, rules, pending.scores, request.signal, trafficLog);
      if (!waiting()) return;
      current.communityFinish = undefined;
      const rule = primaryResultRule(rules);
      const scores = [undefined, undefined];
      scores[current.localSlot] = pending.scores.find((item) => item.type === rule?.rule_code)?.score;
      showSettlement({ ...current.settlement, scores, scoreUnit: resultRuleUnit(rule) });
    } catch (error) {
      if (!waiting()) return;
      const message = request.signal.aborted ? "成绩提交超时，请重试。" : error?.message ?? "成绩提交失败。";
      view.setCommunitySubmission?.("failed", message);
      if (request.signal.aborted || error instanceof RoomConnectionError) {
        roomConnectionFailed(new Error(message), "submitCommunityResult");
      } else report(new Error(message), "submitCommunityResult");
    } finally {
      clearTimeout(timeout);
      if (scoreRequest === request) scoreRequest = undefined;
    }
  }

  function stopGame(current, reason) {
    current.controller.abort(reason);
    try {
      game.stop({ roundId: current.id, reason });
    } catch (error) {
      report(error, "stopGame");
    }
  }

  function uploadStatus(current) {
    const { scores, players, localSlot } = current.settlement;
    if (!settlement.onUpload || !players[localSlot] || scores[localSlot] === undefined) return "unavailable";
    if (current.uploading) return "uploading";
    return current.uploadedScore === scores[localSlot] ? "uploaded" : "ready";
  }

  function showSettlement(next) {
    round.settlement = next;
    view.showSettlement(next);
    view.setSettlementUpload(uploadStatus(round));
  }

  async function uploadSettlement() {
    const current = round;
    if (!current?.settlement || current.settlement.status === "closed" || uploadStatus(current) !== "ready") return;
    const { players, localSlot, scores, status } = current.settlement;
    const score = scores[localSlot];
    current.uploading = true;
    view.setSettlementUpload("uploading");
    let failed = false;
    try {
      await settlement.onUpload({ gameId, roundId: current.id, playerId: players[localSlot].id, score, status });
      current.uploadedScore = score;
    } catch (error) {
      failed = true;
      report(error, "uploadSettlement");
    } finally {
      current.uploading = false;
      if (round === current && current.settlement && current.settlement.status !== "closed") {
        view.setSettlementUpload(
          uploadStatus(current), failed && current.settlement.scores[localSlot] === score,
        );
      }
    }
  }

  async function exitSettlement() {
    if (!round?.settlement) return;
    const detail = { gameId, roundId: round.id, status: round.settlement.status };
    enterLobby();
    try {
      await settlement.onExit?.(detail);
    } catch (error) {
      report(error, "exitSettlement");
    }
  }

  function waitForResult(reason, finish) {
    phase = "waiting";
    const communityFinish = room && !transport && reason === "game";
    if (communityFinish) round.communityFinish = { scores: finish.data?.scores };
    else round.finish = finish;
    stopGame(round, reason);
    if (phase === "waiting") {
      const rule = communityFinish ? primaryResultRule(roomInfo?.result_rules) : undefined;
      const reported = round.communityFinish?.scores;
      const score = Array.isArray(reported) ? reported.find((item) => item?.type === rule?.rule_code)?.score : undefined;
      const scores = [undefined, undefined];
      if (Number.isFinite(score)) scores[round.localSlot] = score;
      showSettlement({
        status: "waiting", players: round.players, localSlot: round.localSlot, scores, scoreUnit: resultRuleUnit(rule),
      });
      if (communityFinish) void sendCommunityFinish();
      else sendFinish();
    }
  }

  function startRound({ roundId, payload }) {
    const current = {
      id: roundId, controller: new AbortController(), players: lobbyState.players, localSlot: lobbyState.localSlot,
    };
    startedRounds.add(roundId);
    round = current;
    phase = "playing";
    clearLobbyAction();
    const container = view.showGame();
    const isPlaying = () => phase === "playing" && round === current;
    const finish = (data) => {
      if (!isPlaying()) return false;
      waitForResult("game", { reason: "game", data });
      return true;
    };
    const failed = (error) => {
      if (!isPlaying()) return;
      waitForResult("game-error", { reason: "game-error" });
      report(error, "startGame");
    };
    try {
      Promise.resolve(game.start({
        container, gameId, roundId, payload, signal: current.controller.signal, finish,
        send(type, data) {
          if (!isPlaying()) throw new Error("The round has ended");
          send(type, data, roundId);
        },
      })).catch(failed);
    } catch (error) {
      failed(error);
    }
  }

  function applySettlement(next) {
    if (next.status === "waiting" && phase !== "waiting") return;
    const wasPlaying = phase === "playing";
    const nextPhase = next.status === "waiting" ? "waiting" : "result";
    phase = nextPhase;
    round.finish = undefined;
    if (nextPhase === "result") scoreRequest?.abort();
    round.players = next.players;
    clearFinishError();
    if (wasPlaying) stopGame(round, next.status === "closed" ? "server" : "result");
    if (phase === nextPhase) showSettlement(next);
  }

  function receive(message) {
    if (!message || !hasId(message.type) || !hasId(message.gameId)) {
      report(new TypeError("Invalid SDK message"), "receive");
      return;
    }
    if (message.gameId !== gameId) return;

    const { type, roundId, payload } = message;
    if (type === "round.start" || type === "round.forceEnd" || type === "round.result") {
      if (!hasId(roundId)) {
        report(new TypeError("A round message requires roundId"), "receive");
        return;
      }
      if (type === "round.start") {
        if (phase === "lobby" && !startedRounds.has(roundId)) startRound(message);
        return;
      }
      if (roundId !== round?.id || (phase !== "playing" && phase !== "waiting")) return;
      if (type === "round.forceEnd") {
        if (phase === "playing") waitForResult("server");
        else round.finish = undefined;
        clearFinishError();
        return;
      }
      if (payload?.status !== undefined) {
        let next;
        try {
          next = normalizeSettlement(payload, round);
        } catch (error) {
          report(error, "receive");
          return;
        }
        applySettlement(next);
        return;
      }
      if (!validResult(payload)) {
        report(new TypeError("Invalid round result"), "receive");
        return;
      }
      applySettlement({
        status: "finished", players: round.players, localSlot: round.localSlot,
        scores: [undefined, undefined], summary: payload,
      });
      return;
    }

    if (controls.has(type) || (roundId !== undefined && (phase !== "playing" || roundId !== round.id))) {
      return;
    }
    try {
      onMessage?.(message);
    } catch (error) {
      report(error, "onMessage");
    }
  }

  function clearFinishError() {
    if (!connection?.finishFailed) return;
    connection.finishFailed = false;
    view.setError("");
    view.setConnection(connection.status);
  }

  function disconnect() {
    try {
      transport.disconnect();
    } catch (error) {
      report(error, "disconnect");
    }
  }

  function connect() {
    const attempt = { status: "connecting" };
    connection = attempt;
    view.setConnection("connecting");
    view.setError("");

    function close() {
      attempt.status = "closed";
      view.setConnection("closed");
    }

    try {
      transport.connect({
        onStatus(status) {
          trafficLog?.write("连接状态", { status });
          if (connection !== attempt || attempt.status === "closed") return;
          if (status === "closed") {
            close();
          } else if (status === "open" && attempt.status === "connecting") {
            attempt.status = "open";
            try {
              const message = { type: "game.join", gameId };
              trafficLog?.write("通信发送", message);
              transport.send(message);
            } catch (error) {
              if (connection === attempt) {
                close();
                disconnect();
              }
              report(error, "join");
              return;
            }
            if (connection !== attempt || attempt.status === "closed") return;
            view.setConnection("open", attempt.finishFailed);
            sendFinish();
          }
        },
        onMessage(message) {
          trafficLog?.write("通信接收", message);
          if (connection === attempt && attempt.status === "open") receive(message);
        },
        onError(error) {
          trafficLog?.write("通信错误", { message: error?.message ?? "连接错误" });
          if (connection === attempt) report(error, "transport");
        },
      });
    } catch (error) {
      if (connection === attempt) {
        close();
        disconnect();
      }
      report(error, "connect");
    }
  }

  function reconnect() {
    if (transport) {
      if (connection?.status !== "closed" && !connection?.finishFailed) return false;
      if (connection.status !== "closed") {
        connection = undefined;
        disconnect();
        if (phase === "destroyed") return false;
      }
      connect();
      return true;
    }
    if (wimClient && !roomReleased && wimClient.status === "closed") {
      return wimClient.connect();
    }
    if (phase === "lobby" && room && !roomReleased && !roomInfo && !roomRequest && localProfile && roomAuthToken) {
      void loadRoom(localProfile, roomAuthToken, roomImToken);
      return true;
    }
    return false;
  }

  function enterLobby() {
    scoreRequest?.abort();
    round = undefined;
    phase = "lobby";
    view.showLobby();
  }

  return {
    start() {
      if (phase !== "idle") throw new Error("An SDK instance can only be started once");
      phase = "lobby";
      view.mount({ reconnect, lobbyAction, uploadSettlement, exitSettlement,
        retryCommunitySubmission: room && !transport ? () => sendCommunityFinish(true) : undefined,
      });
      view.showLobby();
      if (startupError) {
        view.setLobbyBusy(true);
        view.setConnection("closed", false);
        roomConnectionFailed(startupError.error, startupError.operation);
        return;
      }
      if (room) view.setLobbyBusy(true);
      if (transport) connect();
      if (phase !== "destroyed") {
        if (room && appUser) {
          appUserTimer = setTimeout(() => {
            if (!transport) view.setConnection("closed", false);
            roomConnectionFailed(new Error("等待 App 登录信息超时。"), "读取 App 登录信息");
          }, 10000);
        }
        appUser?.start({
          onUser(profile, authToken, imToken) {
            clearTimeout(appUserTimer);
            if (room) void loadRoom(profile, authToken, imToken);
            void notifyAppUser(profile);
          },
          async onGuestRequired() {
            clearTimeout(appUserTimer);
            if (room) {
              if (!transport) view.setConnection("closed", false);
              roomConnectionFailed(new Error("缺少 App 登录信息，请从 App 的房间卡片进入。"), "读取 App 登录信息");
            }
            try {
              await onGuestRequired?.({ gameId });
            } catch (error) {
              report(error, "onGuestRequired");
            }
          },
          onError(error) {
            clearTimeout(appUserTimer);
            if (room) {
              if (!transport) view.setConnection("closed", false);
              roomConnectionFailed(error, "queryAppInitInfo");
            } else report(error, "queryAppInitInfo");
          },
        });
      }
    },
    reconnect,
    getAppUser() {
      return appUser?.get() ?? null;
    },
    getRoomInfo() {
      return roomInfo;
    },
    updateLobby,
    send(type, payload) {
      send(type, payload);
    },
    destroy() {
      if (phase === "destroyed") return;
      const wasPlaying = phase === "playing";
      phase = "destroyed";
      clearTimeout(appUserTimer);
      appUser?.destroy();
      roomRequest?.abort();
      scoreRequest?.abort();
      const activeWim = wimClient;
      wimClient = undefined;
      activeWim?.disconnect();
      roomInfo = null;
      roomAuthToken = null;
      roomImToken = null;
      localPlayerId = null;
      localProfile = null;
      clearLobbyAction();
      const wasConnected = connection !== undefined;
      connection = undefined;
      if (wasPlaying) stopGame(round, "destroy");
      round = undefined;
      startedRounds.clear();
      if (wasConnected) disconnect();
      view.destroy();
    },
  };
}
