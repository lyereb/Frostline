const channelName = "whackGameBridge";
let nextRequestId = 0;

function bridgeError(code, message, cause) {
  return Object.assign(new Error(message, { cause }), { code });
}

function findNativeChannel(host) {
  const ios = host?.webkit?.messageHandlers?.[channelName];
  if (typeof ios?.postMessage === "function") return { platform: "ios", channel: ios };
  const android = host?.[channelName];
  if (typeof android?.postMessage === "function" && typeof android.addEventListener === "function" &&
    typeof android.removeEventListener === "function") {
    return { platform: "android", channel: android };
  }
  return null;
}

export function createAppBridge({ host = globalThis.window, timeoutMs = 5000 } = {}) {
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 2_147_483_647) {
    throw new RangeError("timeoutMs must be a positive timer duration in milliseconds");
  }

  const { platform, channel } = findNativeChannel(host) ?? { platform: null };
  const pending = new Map();
  let destroyed = false;

  function finish(id, error, result) {
    const request = pending.get(id);
    if (!request) return;
    pending.delete(id);
    clearTimeout(request.timer);
    if (error) request.reject(error);
    else request.resolve(result);
  }

  function receive(raw, expectedId) {
    let response;
    try {
      response = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch (error) {
      if (expectedId) finish(expectedId, bridgeError("INVALID_RESPONSE", "Invalid native reply JSON", error));
      return;
    }

    const id = response?.id;
    if (expectedId && id !== expectedId) {
      finish(expectedId, bridgeError("INVALID_RESPONSE", "Native reply does not match its request"));
      return;
    }
    if (!pending.has(id)) return;
    if (response.ok === true) {
      finish(id, null, response.result);
    } else if (response.ok === false && typeof response.error?.message === "string") {
      const { code, message } = response.error;
      finish(id, bridgeError(typeof code === "string" ? code : "NATIVE_ERROR", message));
    } else {
      finish(id, bridgeError("INVALID_RESPONSE", "Invalid native reply"));
    }
  }

  function onAndroidMessage(event) {
    receive(event.data);
  }

  if (platform === "android") channel.addEventListener("message", onAndroidMessage);

  return {
    get available() { return platform !== null && !destroyed; },
    platform,
    async call(method, params) {
      if (typeof method !== "string" || !method.trim()) {
        throw new TypeError("A native bridge method is required");
      }
      if (destroyed) throw bridgeError("DESTROYED", "The app bridge has been destroyed");
      if (platform === null) throw bridgeError("UNAVAILABLE", "No app bridge is available");

      const id = `whack-${++nextRequestId}`;
      const payload = JSON.stringify({ id, method, params });

      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => finish(id, bridgeError("TIMEOUT", `Native request timed out: ${method}`)), timeoutMs);
        pending.set(id, { resolve, reject, timer });

        try {
          if (platform === "android") {
            channel.postMessage(payload);
            return;
          }

          const reply = channel.postMessage(payload);
          if (typeof reply?.then !== "function") {
            finish(id, bridgeError("INVALID_RESPONSE", "The iOS bridge requires a reply handler"));
            return;
          }
          Promise.resolve(reply).then(
            (response) => receive(response, id),
            (error) => finish(id, bridgeError("NATIVE_ERROR", error?.message ?? String(error), error)),
          );
        } catch (error) {
          finish(id, bridgeError("POST_FAILED", `Could not send native request: ${method}`, error));
        }
      });
    },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      if (platform === "android") channel.removeEventListener("message", onAndroidMessage);
      const error = bridgeError("DESTROYED", "The app bridge has been destroyed");
      for (const id of pending.keys()) finish(id, error);
    },
  };
}

const text = (value) => typeof value === "string" ? value.trim() : "";

class AppInitError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

function readAppInitUser(bridge) {
  if (!bridge) throw new AppInitError("bridge_missing", "页面未检测到 WKWebViewJavascriptBridge。");
  if (typeof bridge.JSQueryInitInfo !== "function") {
    throw new AppInitError("method_missing", "App 未提供 JSQueryInitInfo 方法。");
  }
  let response;
  try {
    response = bridge.JSQueryInitInfo();
  } catch {
    throw new AppInitError("call_failed", "调用 JSQueryInitInfo 时发生错误。");
  }
  if (typeof response !== "string") {
    throw new AppInitError("invalid_response", "JSQueryInitInfo 应同步返回 JSON 字符串。");
  }
  let user;
  try {
    user = JSON.parse(response)?.user;
  } catch {
    throw new AppInitError("invalid_json", "JSQueryInitInfo 返回的内容无法解析为 JSON。");
  }
  if (!user || typeof user !== "object" || Array.isArray(user)) {
    throw new AppInitError("user_missing", "JSQueryInitInfo 的返回值缺少 user 对象。");
  }
  return user;
}

function appProfile(user) {
  const id = text(user.user_id);
  if (!id) throw new AppInitError("user_id_missing", "user.user_id 缺失或不是有效字符串。");
  return Object.freeze({
    id,
    nickname: text(user.nick_name) || text(user.nickname),
    avatarUrl: text(user.head_img) || text(user.avatar),
  });
}

export function createAppUserReader(document, appBridge, readRoomToken = false) {
  const host = document.defaultView;
  let callbacks;
  let queried = false;
  let guestNotified = false;
  let profile = null;

  function read() {
    if (!callbacks || queried) return;
    const bridge = host?.WKWebViewJavascriptBridge;
    if (typeof bridge?.JSQueryInitInfo !== "function") return;

    queried = true;
    host.removeEventListener("load", checkHost);
    const current = callbacks;
    let nextProfile;
    let roomToken;
    let imToken;
    try {
      const user = readAppInitUser(bridge);
      nextProfile = appProfile(user);
      if (readRoomToken) {
        roomToken = text(user.auth_token);
        imToken = text(user.im_token);
      }
    } catch {
      if (callbacks === current) current.onError(new Error("Could not read the App user profile"));
      return;
    }
    if (callbacks !== current) return;
    profile = nextProfile;
    current.onUser(profile, roomToken, imToken);
  }

  function checkHost() {
    if (!callbacks) return;
    read();
    if (!callbacks || queried || guestNotified || host?.WKWebViewJavascriptBridge ||
      appBridge?.available || findNativeChannel(host)) return;
    guestNotified = true;
    callbacks.onGuestRequired?.();
  }

  return {
    start(nextCallbacks) {
      callbacks = nextCallbacks;
      read();
      if (queried || !callbacks) return;
      if (document.readyState === "complete") checkHost();
      else host?.addEventListener("load", checkHost, { once: true });
    },
    get() {
      read();
      return profile;
    },
    inspect() {
      try {
        const user = readAppInitUser(host?.WKWebViewJavascriptBridge);
        const { id, nickname, avatarUrl } = appProfile(user);
        return {
          ok: true, id, nickname,
          hasAvatar: Boolean(avatarUrl),
          hasHttpCredential: Boolean(text(user.auth_token)),
          hasWimCredential: Boolean(text(user.im_token)),
        };
      } catch (error) {
        if (error instanceof AppInitError) return { ok: false, code: error.code, message: error.message };
        return { ok: false, code: "call_failed", message: "读取 App 登录桥时发生错误。" };
      }
    },
    destroy() {
      host?.removeEventListener("load", checkHost);
      callbacks = undefined;
      profile = null;
    },
  };
}
