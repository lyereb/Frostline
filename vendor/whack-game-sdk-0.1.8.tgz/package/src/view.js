import { createDuelLobby } from "./duel-lobby.js";
import { createDuelSettlement } from "./duel-settlement.js";

const connectionLabels = {
  connecting: "正在连接服务器",
  open: "已连接",
  closed: "服务器连接已断开",
};

export function createView(root, title, lobbyOptions, showConnection = true, trafficLog) {
  const document = root.ownerDocument;
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  const shell = element("section", "whack-sdk");
  const header = element("header", "whack-sdk-header");
  header.hidden = !showConnection;
  const status = element("span", "whack-sdk-status");
  status.setAttribute("role", "status");
  const retry = element("button", "whack-sdk-button whack-sdk-button-secondary", "重新连接");
  retry.type = "button";
  retry.hidden = true;
  header.append(status, retry);

  const error = element("p", "whack-sdk-error");
  error.setAttribute("role", "alert");
  error.hidden = true;
  const screen = element("div", "whack-sdk-screen");
  shell.append(header, error, screen);
  let actions;
  let settlementView;
  let iconUrl = lobbyOptions.iconUrl;
  const lobby = createDuelLobby(element, title, lobbyOptions, (action) => actions.lobbyAction(action), trafficLog);
  shell.append(...lobby.dialogs);

  return {
    mount(nextActions) {
      actions = nextActions;
      retry.addEventListener("click", () => {
        retry.closest("dialog")?.close();
        actions.reconnect();
      });
      root.append(shell);
    },
    setConnection(state, canRetry = state === "closed") {
      header.hidden = false;
      status.textContent = connectionLabels[state];
      status.dataset.connection = state;
      retry.hidden = !canRetry;
    },
    setError(message) {
      error.textContent = message;
      error.hidden = !message;
    },
    showLobby() {
      settlementView = undefined;
      lobby.debugConnection?.append(header);
      screen.dataset.screen = "lobby";
      screen.replaceChildren(lobby.element);
    },
    updateLobby: lobby.update,
    updateRoomBranding({ title: nextTitle, iconUrl: nextIconUrl, rules }) {
      title = nextTitle || title;
      iconUrl = nextIconUrl || iconUrl;
      lobby.updateBranding({ title, iconUrl, rules });
    },
    setLobbyBusy: lobby.setBusy,
    setLobbyError: lobby.setError,
    showLobbyStarted: lobby.showStarted,
    showConnectionFailure: lobby.showConnectionFailure,
    clearConnectionFailure: lobby.clearConnectionFailure,
    showGame() {
      const container = element("div", "whack-sdk-game");
      shell.prepend(header);
      screen.dataset.screen = "playing";
      screen.replaceChildren(container);
      return container;
    },
    showSettlement(result) {
      const oldStatus = settlementView?.element.dataset.status;
      settlementView = createDuelSettlement(element, { title, iconUrl, actions, result });
      if (header.parentElement !== shell) shell.prepend(header);
      screen.dataset.screen = "settlement";
      screen.replaceChildren(settlementView.element);
      if (oldStatus !== result.status) shell.scrollTop = 0;
    },
    setSettlementUpload(value, failed) { settlementView?.setUploadStatus(value, failed); },
    setCommunitySubmission(state, message) { settlementView?.setCommunitySubmission(state, message); },
    destroy() {
      shell.remove();
    },
  };
}

