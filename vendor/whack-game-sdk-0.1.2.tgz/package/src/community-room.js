const maxId = 9_223_372_036_854_775_807n;

function decimalId(value) {
  const text = Number.isSafeInteger(value) ? String(value) : value;
  if (typeof text !== "string" || !/^(0|[1-9]\d{0,18})$/.test(text) || BigInt(text) > maxId) return null;
  return text;
}

export function readCommunityRoom(pageUrl, apiBaseUrl) {
  const page = new URL(pageUrl);
  const params = page.searchParams;
  if (apiBaseUrl === undefined && !params.has("group_id") && !params.has("game_id")) {
    return null;
  }

  const groupId = decimalId(params.get("group_id"));
  const gameId = decimalId(params.get("game_id"));
  const chatRoomId = (params.get("id") ?? params.get("chat_room_id"))?.trim();
  if (groupId === null || !gameId || gameId === "0" || !chatRoomId) {
    throw new TypeError("Community PK URL requires group_id, game_id and chat_room_id (or id)");
  }
  if (apiBaseUrl !== undefined && (typeof apiBaseUrl !== "string" || !apiBaseUrl.trim())) {
    throw new TypeError("roomApiBaseUrl must be a non-empty URL");
  }
  const endpoint = new URL("/games/room/info", apiBaseUrl === undefined ? page : new URL(apiBaseUrl, page));
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(endpoint.hostname);
  if (endpoint.protocol !== "https:" && !(endpoint.protocol === "http:" && local)) {
    throw new TypeError("Community PK room API requires HTTPS");
  }
  return { groupId, gameId, chatRoomId, endpoint };
}

function apiMessage(result, fallback) {
  const msg = typeof result?.msg === "string" ? result.msg.trim() : "";
  if (msg) return msg;
  const suffix = Number.isSafeInteger(result?.code) ? `（错误码 ${result.code}）` : "";
  return `${fallback}${suffix}。`;
}

async function postCommunityApi(room, path, authToken, params, signal, log, labels) {
  if (!authToken) throw new Error("缺少游戏登录凭证，请从 App 重新进入。");
  const endpoint = path === "/games/room/info" ? room.endpoint : new URL(path, room.endpoint);
  log?.write(`HTTP 发送 POST ${path}`, params);
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${authToken}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams(params),
    signal,
    redirect: "error",
    cache: "no-store",
  });
  let result;
  try {
    result = await response.json();
  } catch {
    result = undefined;
  }
  if (!response.ok) {
    log?.write("HTTP 响应", result === undefined ? { status: response.status } : { status: response.status, body: result });
    if (labels.useServerMsg && typeof result?.msg === "string" && result.msg.trim()) {
      throw new Error(result.msg.trim());
    }
    throw new Error(`${labels.httpError}（HTTP ${response.status}）。`);
  }
  if (result === undefined) {
    log?.write("HTTP 响应", { status: response.status, error: "响应格式无效" });
    throw new Error(labels.invalidFormat);
  }
  log?.write("HTTP 响应", { status: response.status, body: result });
  if (result?.code !== 0) {
    if (labels.useServerMsg) throw new Error(apiMessage(result, labels.codeError));
    const suffix = Number.isSafeInteger(result?.code) ? `（错误码 ${result.code}）` : "";
    throw new Error(`${labels.codeError}${suffix}。`);
  }
  return result.data;
}

export async function fetchCommunityRoom(room, authToken, playerId, signal, log) {
  const info = await postCommunityApi(
    room,
    "/games/room/info",
    authToken,
    { group_id: room.groupId, game_id: room.gameId, chat_room_id: room.chatRoomId },
    signal,
    log,
    {
      httpError: "房间信息请求失败",
      invalidFormat: "服务器返回的房间数据格式无效。",
      codeError: "服务器未能返回房间信息",
      useServerMsg: false,
    },
  );
  if (decimalId(info?.group_id) !== room.groupId || decimalId(info?.game_id) !== room.gameId ||
      info.chat_room_id !== room.chatRoomId || decimalId(info.user?.user_id) !== playerId ||
      (info.creator != null && decimalId(info.creator?.user_id) === null) ||
      !Array.isArray(info.players) || !Number.isInteger(info.status) || typeof info.locked !== "boolean") {
    throw new Error("房间信息与当前链接或玩家不匹配。");
  }
  return info;
}

export async function applyCommunityRoom(room, authToken, { index, status, isNpc = false }, signal, log) {
  if (!Number.isInteger(index) || index < 1 || (status !== 0 && status !== 1)) {
    throw new TypeError("Community PK apply requires a positive seat index and status 0 or 1");
  }
  return postCommunityApi(
    room,
    "/games/room/apply",
    authToken,
    {
      group_id: room.groupId,
      game_id: room.gameId,
      chat_room_id: room.chatRoomId,
      index: String(index),
      status: String(status),
      is_npc: String(Boolean(isNpc)),
    },
    signal,
    log,
    {
      httpError: status === 1 ? "报名请求失败" : "取消报名请求失败",
      invalidFormat: "服务器返回的报名响应格式无效。",
      codeError: status === 1 ? "报名失败" : "取消报名失败",
      useServerMsg: true,
    },
  );
}

export async function startCommunityRoom(room, authToken, signal, log) {
  return postCommunityApi(
    room,
    "/games/room/start",
    authToken,
    {
      group_id: room.groupId,
      game_id: room.gameId,
      chat_room_id: room.chatRoomId,
    },
    signal,
    log,
    {
      httpError: "开始游戏请求失败",
      invalidFormat: "服务器返回的开始游戏响应格式无效。",
      codeError: "开始游戏失败",
      useServerMsg: true,
    },
  );
}

export async function submitCommunityResult(room, authToken, rules, scores, signal, log) {
  if (!Array.isArray(rules) || rules.length === 0) {
    throw new Error("房间未返回结算规则，暂时无法提交成绩。");
  }
  const types = new Set(rules.map((rule) => rule?.rule_code));
  if ([...types].some((type) => typeof type !== "string" || !type.trim())) {
    throw new Error("房间返回的成绩指标无效。");
  }
  if (!Array.isArray(scores) || scores.length !== types.size ||
      scores.some((item) => !types.delete(item?.type) || !Number.isFinite(item.score))) {
    throw new Error("游戏成绩必须为房间的每项结算规则提供一个有效数值。");
  }
  return postCommunityApi(
    room,
    "/games/room/result",
    authToken,
    {
      group_id: room.groupId,
      game_id: room.gameId,
      chat_room_id: room.chatRoomId,
      completed: "true",
      scores: JSON.stringify(scores.map(({ type, score }) => ({ type, score }))),
    },
    signal,
    log,
    {
      httpError: "成绩提交请求失败",
      invalidFormat: "服务器返回的成绩提交响应格式无效。",
      codeError: "成绩提交失败",
      useServerMsg: true,
    },
  );
}

export function primaryResultRule(rules) {
  return Array.isArray(rules)
    ? rules.filter((rule) => typeof rule?.rule_code === "string")
      .reduce((first, rule) => !first || (rule.priority_weight ?? 0) < (first.priority_weight ?? 0) ? rule : first, undefined)
    : undefined;
}

export function resultRuleUnit(rule) {
  try {
    const unit = JSON.parse(rule?.rule_config)?.unit;
    return typeof unit === "string" && unit.trim() ? unit.trim() : undefined;
  } catch {
    return undefined;
  }
}

export function resolveCommunityWsUrl(room, wsUrl, pageUrl) {
  const base = pageUrl ? new URL(pageUrl) : room.endpoint;
  if (wsUrl === undefined) {
    const derived = new URL("/ws", room.endpoint);
    derived.protocol = room.endpoint.protocol === "https:" ? "wss:" : "ws:";
    return derived;
  }
  if (typeof wsUrl !== "string" || !wsUrl.trim()) {
    throw new TypeError("roomWsUrl must be a non-empty WebSocket URL");
  }
  const resolved = new URL(wsUrl, base);
  if (resolved.protocol !== "wss:" && resolved.protocol !== "ws:") {
    throw new TypeError("Community PK WIM WebSocket URL must use ws: or wss:");
  }
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(resolved.hostname);
  if (resolved.protocol === "ws:" && !local && base.protocol === "https:") {
    throw new TypeError("Community PK WIM WebSocket requires WSS on HTTPS pages");
  }
  return resolved;
}

export function applyRoomApplyEvent(info, eventData) {
  if (!info || !eventData || !Number.isInteger(eventData.index) || eventData.index < 1) return info;
  const userId = decimalId(eventData.user?.user_id);
  if (!userId) return info;
  const existing = info.players.filter((seat) =>
    decimalId(seat?.user?.user_id) !== userId && seat?.index !== eventData.index);
  return {
    ...info,
    players: [
      ...existing,
      {
        user: eventData.user,
        index: eventData.index,
        status: 1,
        is_npc: Boolean(eventData.is_npc),
      },
    ],
  };
}

export function applyRoomUnapplyEvent(info, eventData) {
  if (!info || !eventData) return info;
  const userId = decimalId(eventData.user?.user_id);
  if (!userId) return info;
  return {
    ...info,
    players: info.players.filter((seat) => decimalId(seat?.user?.user_id) !== userId),
  };
}

export function matchesCommunityRoomEvent(room, eventData) {
  if (!room || !eventData || typeof eventData !== "object") return false;
  return decimalId(eventData.group_id) === room.groupId &&
    decimalId(eventData.game_id) === room.gameId &&
    eventData.chat_room_id === room.chatRoomId;
}

export function communitySettlementFromResult(resultData, round, roomRules) {
  const players = round.players;
  const status = resultData?.status;
  const resultPlayers = Array.isArray(resultData?.players) ? resultData.players : [];
  const memberScores = Array.isArray(resultData?.member_scores) ? resultData.member_scores : [];
  const hasScores = resultPlayers.some((p) => Array.isArray(p?.scores) && p.scores.length > 0) ||
    memberScores.length > 0;
  if ((status === 254 || status === 255) && !hasScores) {
    return {
      status: "closed",
      players,
      localSlot: round.localSlot,
      scores: [undefined, undefined],
    };
  }

  const rule = primaryResultRule(resultData?.result_rules) ?? primaryResultRule(roomRules);
  const primaryCode = rule?.rule_code;

  function scoreFor(player) {
    if (!player) return "—";
    const entry = resultPlayers.find((item) => decimalId(item?.user_id) === player.id);
    const list = Array.isArray(entry?.scores) && entry.scores.length > 0
      ? entry.scores
      : memberScores.filter((item) => decimalId(item?.user_id) === player.id);
    const matched = (primaryCode ? list.find((item) => item?.type === primaryCode) : undefined) ?? list[0];
    return Number.isFinite(matched?.score) || typeof matched?.score === "string" ? matched.score : "—";
  }

  const winners = new Set(
    Array.isArray(resultData?.winner_user_ids)
      ? resultData.winner_user_ids.map((id) => decimalId(id)).filter(Boolean)
      : [],
  );
  const slot0Won = Boolean(players[0] && winners.has(players[0].id));
  const slot1Won = Boolean(players[1] && winners.has(players[1].id));
  const winnerSlot = slot0Won && !slot1Won ? 0 : (slot1Won && !slot0Won ? 1 : null);

  return {
    status: "finished",
    players,
    localSlot: round.localSlot,
    scores: [scoreFor(players[0]), scoreFor(players[1])],
    scoreUnit: resultRuleUnit(rule),
    winnerSlot,
  };
}

export function communityLobbyState(info, playerId) {
  const hostId = decimalId(info.creator?.user_id);
  const players = [null, null];
  for (const seat of info.players) {
    if (seat?.index !== 1 && seat?.index !== 2) continue;
    const id = decimalId(seat.user?.user_id);
    if (!id || players[seat.index - 1] || (seat.status !== 0 && seat.status !== 1)) {
      throw new Error("服务器返回的房间座位数据无效。");
    }
    const name = typeof seat.user.nick_name === "string" && seat.user.nick_name.trim()
      ? seat.user.nick_name.trim()
      : undefined;
    const player = {
      id,
      avatarUrl: typeof seat.user.head_img === "string" ? seat.user.head_img : undefined,
      ready: seat.status === 1,
      isHost: Boolean(hostId && id === hostId),
    };
    if (name !== undefined) player.name = name;
    players[seat.index - 1] = player;
  }
  const localSlot = players.findIndex((player) => player?.id === playerId);
  const seated = localSlot !== -1;
  const isHost = Boolean(hostId && hostId === playerId);
  const open = info.status === 1 && !info.locked;
  const ready = seated && players[localSlot].ready;
  const bothSeated = players.every(Boolean);
  return {
    players,
    localSlot: seated ? localSlot : 0,
    isHost,
    ready,
    canJoin: open && !seated && players.some((player) => player === null),
    canReady: open && seated && !(isHost && ready),
    canStart: isHost && open && bothSeated,
    inProgress: info.status === 3,
  };
}
