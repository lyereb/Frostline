function parseJsonMaybe(value) {
  if (typeof value !== "string") return value;
  return JSON.parse(value);
}

function sameDecimalId(value, expected) {
  if (value === undefined || value === null) return false;
  const text = Number.isSafeInteger(value) ? String(value) : String(value);
  return text === expected;
}

export function createCommunityWimClient({
  url, roomId, playerId, token, WebSocketImpl = globalThis.WebSocket, log,
  onStatus, onJoined, onEvent, onReleased, onError,
}) {
  if (typeof WebSocketImpl !== "function") {
    throw new Error("WebSocket is not available in this environment");
  }
  const baseUrl = url instanceof URL ? new URL(url.href) : new URL(url);
  const logUrl = `${baseUrl.origin}${baseUrl.pathname}`;
  let socket;
  let status = "idle";
  let joined = false;
  let released = false;

  function setStatus(next) {
    if (status === next) return;
    status = next;
    log?.write("WIM 连接状态", { status: next, room_id: roomId });
    onStatus?.(next);
  }

  function sendRaw(current, message) {
    if (socket !== current || current.readyState !== WebSocketImpl.OPEN) return false;
    log?.write("WIM 发送", message);
    current.send(JSON.stringify(message));
    return true;
  }

  function handleMessage(current, raw) {
    if (socket !== current) return;
    let envelope;
    try {
      const text = typeof raw === "string"
        ? raw
        : new TextDecoder().decode(raw instanceof ArrayBuffer ? new Uint8Array(raw) : raw);
      envelope = JSON.parse(text);
    } catch (error) {
      onError?.(new Error("WIM 消息 JSON 解析失败", { cause: error }));
      return;
    }
    log?.write("WIM 接收", envelope);

    const { type, payload } = envelope ?? {};
    if (type === "connection.ready") {
      if (payload?.user_id !== undefined && playerId && !sameDecimalId(payload.user_id, playerId)) {
        onError?.(new Error("WIM 连接用户与当前玩家不匹配。"));
        disconnect();
        return;
      }
      try {
        sendRaw(current, { type: "room.join", payload: { room_id: roomId } });
      } catch (error) {
        onError?.(error);
        disconnect();
      }
      return;
    }

    if (type === "room.joined") {
      if (payload?.room_id !== roomId) return;
      joined = true;
      setStatus("open");
      onJoined?.();
      return;
    }

    if (type === "room.left") {
      if (payload?.room_id === roomId) joined = false;
      return;
    }

    if (type === "room.released") {
      if (payload?.room_id !== roomId) return;
      released = true;
      joined = false;
      const active = socket;
      socket = undefined;
      try {
        active?.close();
      } catch {
        // Ignore close errors after release.
      }
      setStatus("closed");
      onReleased?.();
      return;
    }

    if (type === "message.created") {
      const message = payload?.message;
      if (!message || message.room_id !== roomId) return;
      let content;
      let eventData;
      try {
        content = parseJsonMaybe(message.content);
        if (!content || typeof content !== "object" || typeof content.event !== "string") {
          return;
        }
        eventData = content.data === undefined ? undefined : parseJsonMaybe(content.data);
      } catch (error) {
        onError?.(new Error("WIM 房间事件解析失败", { cause: error }));
        return;
      }
      onEvent?.({ event: content.event, data: eventData, message });
    }
  }

  function connect() {
    if (released || socket) return false;
    const connectUrl = new URL(baseUrl.href);
    connectUrl.searchParams.set("token", token);
    log?.write("WIM 连接", { url: logUrl, room_id: roomId });
    setStatus("connecting");

    let current;
    try {
      current = new WebSocketImpl(connectUrl.href);
    } catch (error) {
      setStatus("closed");
      onError?.(error);
      return false;
    }
    socket = current;
    joined = false;

    current.addEventListener("message", ({ data }) => handleMessage(current, data));
    current.addEventListener("error", () => {
      if (socket === current) onError?.(new Error("WIM WebSocket 连接错误"));
    });
    current.addEventListener("close", () => {
      if (socket !== current) return;
      socket = undefined;
      joined = false;
      setStatus("closed");
    });
    return true;
  }

  function disconnect() {
    const current = socket;
    if (!current) {
      if (status !== "closed") setStatus("closed");
      return;
    }
    if (joined && !released && current.readyState === WebSocketImpl.OPEN) {
      try {
        sendRaw(current, { type: "room.leave", payload: { room_id: roomId } });
      } catch {
        // Best-effort leave before closing socket.
      }
    }
    socket = undefined;
    joined = false;
    try {
      current.close();
    } catch {
      // Ignore close failures on teardown.
    }
    setStatus("closed");
  }

  return {
    connect,
    disconnect,
    get status() { return status; },
    get joined() { return joined; },
    get released() { return released; },
  };
}
