import { createAppUserReader } from "./app-bridge.js";
import { readCommunityRoom, resolveCommunityWsUrl } from "./community-room.js";
import { createSession } from "./session.js";
import { createView } from "./view.js";
import { createTrafficLog } from "./traffic-log.js";

export { createWebSocketTransport } from "./websocket.js";
export { createAppBridge } from "./app-bridge.js";

function requireRoot(root) {
  if (!root || root.nodeType !== 1) {
    throw new TypeError("root must be a DOM element");
  }
}

export function createGameSdk({
  root, gameId, game, transport, title = "游戏大厅", lobby = {}, settlement = {}, appBridge, onAppUser, onGuestRequired,
  roomApiBaseUrl, roomWsUrl, onMessage, onError,
}) {
  requireRoot(root);
  const room = readCommunityRoom(root.ownerDocument.URL, roomApiBaseUrl);
  const resolvedRoomWsUrl = room && roomWsUrl !== undefined
    ? resolveCommunityWsUrl(room, roomWsUrl, root.ownerDocument.URL)
    : undefined;
  gameId = room?.gameId ?? gameId;
  if (typeof gameId !== "string" || !gameId.trim()) {
    throw new TypeError("gameId must be a non-empty string");
  }
  if (typeof game?.start !== "function" || typeof game.stop !== "function") {
    throw new TypeError("game must implement start and stop");
  }
  if ((!room || transport !== undefined) &&
      ["connect", "send", "disconnect"].some((name) => typeof transport?.[name] !== "function")) {
    throw new TypeError("transport must implement connect, send and disconnect");
  }
  if (!lobby || typeof lobby !== "object" || (lobby.mode !== undefined && lobby.mode !== "duel")) {
    throw new TypeError("The supported lobby mode is duel");
  }
  if (["iconUrl", "rules"].some((name) => lobby[name] !== undefined && typeof lobby[name] !== "string")) {
    throw new TypeError("lobby.iconUrl and lobby.rules must be strings");
  }
  if (["onAction", "onMinimize", "onExit"].some((name) =>
    lobby[name] !== undefined && typeof lobby[name] !== "function")) {
    throw new TypeError("Lobby action handlers must be functions");
  }
  if (!settlement || typeof settlement !== "object" || ["onUpload", "onExit"].some((name) =>
    settlement[name] !== undefined && typeof settlement[name] !== "function")) {
    throw new TypeError("Settlement action handlers must be functions");
  }
  if (appBridge !== undefined && (typeof appBridge?.available !== "boolean" || typeof appBridge.call !== "function")) {
    throw new TypeError("appBridge must expose available and call");
  }
  if (onAppUser !== undefined && typeof onAppUser !== "function") {
    throw new TypeError("onAppUser must be a function");
  }
  if (onGuestRequired !== undefined && typeof onGuestRequired !== "function") {
    throw new TypeError("onGuestRequired must be a function");
  }
  if (appBridge?.available) {
    let closeRequest;
    function closeGame(detail) {
      closeRequest ??= Promise.resolve().then(() => appBridge.call("closeGame", { gameId, ...detail })).finally(() => {
        closeRequest = undefined;
      });
      return closeRequest;
    }
    lobby = { ...lobby, onExit: lobby.onExit ?? (() => closeGame({ source: "lobby" })) };
    settlement = {
      ...settlement,
      onExit: settlement.onExit ?? (({ roundId, status }) => closeGame({ source: "settlement", roundId, status })),
    };
  }
  const trafficLog = createTrafficLog();
  return createSession({
    gameId, game, transport, lobby, settlement, onAppUser, onGuestRequired, onMessage, onError, room, trafficLog,
    roomWsUrl: resolvedRoomWsUrl,
    explicitRoomWsUrl: roomWsUrl !== undefined,
    appUser: createAppUserReader(root.ownerDocument, appBridge, Boolean(room)),
    view: createView(root, title, { ...lobby, communityRoom: Boolean(room) }, Boolean(transport), trafficLog),
  });
}

export async function createGameSdkFromConfig({ root, configUrl = "./sdk.config.json", lobby, ...options }) {
  requireRoot(root);
  if (typeof configUrl !== "string" || !configUrl.trim()) {
    throw new TypeError("configUrl must be a non-empty string");
  }
  const url = new URL(configUrl, root.ownerDocument.baseURI);
  const response = await fetch(url, { cache: "no-cache" });
  if (!response.ok) throw new Error(`Could not load SDK configuration at ${url.href} (HTTP ${response.status})`);

  let config;
  try {
    config = await response.json();
  } catch (error) {
    throw new Error(`Invalid SDK configuration JSON at ${url.href}`, { cause: error });
  }
  if (!config || typeof config !== "object" || Array.isArray(config)) {
    throw new TypeError("SDK configuration must be a JSON object");
  }
  const { gameId, title, roomApiBaseUrl, roomWsUrl, lobby: lobbyConfig = {} } = config;
  if (title !== undefined && typeof title !== "string") {
    throw new TypeError("Configuration title must be a string");
  }
  if (!lobbyConfig || typeof lobbyConfig !== "object" || Array.isArray(lobbyConfig)) {
    throw new TypeError("Configuration lobby must be an object");
  }
  const { mode, rules, iconUrl } = lobbyConfig;
  return createGameSdk({
    ...options,
    root,
    gameId,
    title,
    roomApiBaseUrl: options.roomApiBaseUrl ?? roomApiBaseUrl,
    roomWsUrl: options.roomWsUrl ?? roomWsUrl,
    lobby: {
      mode,
      rules,
      iconUrl: typeof iconUrl === "string" && iconUrl ? new URL(iconUrl, response.url || url).href : iconUrl,
      onAction: lobby?.onAction,
      onMinimize: lobby?.onMinimize,
      onExit: lobby?.onExit,
    },
  });
}
