export function createTrafficLog() {
  const entries = [];
  let changed = () => {};
  function write(label, data) {
    let detail = "";
    try {
      detail = JSON.stringify(data, (key, value) => {
        if (/token|authorization|password|cookie|secret/i.test(key)) return "[已隐藏]";
        if (typeof value === "string") {
          return value.replace(/Bearer\s+[^\s"&,]+/gi, "Bearer [已隐藏]")
            .replace(/(["']?(?:access_token|auth_token|im_token|token|password|authorization|cookie|secret)["']?\s*[:=]\s*["']?)[^\s"',}&]+/gi, "$1[已隐藏]")
            .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, "[已隐藏]");
        }
        return value;
      }, 2) ?? "";
    } catch {
      detail = "[数据无法显示]";
    }
    const limit = 100000;
    if (detail.length > limit) detail = detail.slice(0, limit) + "\n[内容过长，已截断]";
    entries.push(`[${new Date().toLocaleTimeString()}] ${label}\n${detail}`);
    if (entries.length > 100) entries.shift();
    changed(entries.join("\n\n"));
  }
  return {
    write,
    subscribe(callback) { changed = callback; callback(entries.join("\n\n")); },
    clear() { entries.length = 0; changed(""); },
  };
}
