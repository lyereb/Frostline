export function createWebSocketTransport({ url, protocol }) {
  if (typeof url !== "string" || !url.trim()) {
    throw new TypeError("url must be a non-empty string");
  }
  if (typeof protocol?.encode !== "function" || typeof protocol.decode !== "function") {
    throw new TypeError("protocol must implement encode and decode");
  }
  let socket;

  return {
    connect({ onStatus, onMessage, onError }) {
      if (socket) throw new Error("The transport already has a socket");
      const current = new WebSocket(url);
      socket = current;
      current.binaryType = "arraybuffer";
      current.addEventListener("open", () => {
        if (socket === current) onStatus("open");
      });
      current.addEventListener("close", () => {
        if (socket !== current) return;
        socket = undefined;
        onStatus("closed");
      });
      current.addEventListener("error", () => {
        if (socket === current) onError(new Error("WebSocket connection error"));
      });
      current.addEventListener("message", ({ data }) => {
        if (socket !== current) return;
        let message;
        try {
          message = protocol.decode(data);
        } catch (error) {
          onError(error);
          return;
        }
        if (message !== null) onMessage(message);
      });
    },
    send(message) {
      if (socket?.readyState !== WebSocket.OPEN) throw new Error("WebSocket is not open");
      socket.send(protocol.encode(message));
    },
    disconnect() {
      const current = socket;
      socket = undefined;
      current?.close();
    },
  };
}
