import { createGameIcon } from "./duel-brand.js";
import { normalizeLobbyState } from "./duel-state.js";

export function createDuelLobby(element, title, options, dispatch, trafficLog) {
  const dialogs = [];
  function button(className, label, action) {
    const control = element("button", className, label);
    control.type = "button";
    control.addEventListener("click", () => dispatch(action));
    return control;
  }

  const lobby = element("section", "whack-duel");
  const layout = element("div", "whack-duel-layout");
  lobby.append(layout);
  const toolbar = element("header", "whack-duel-toolbar");
  if (options.onMinimize) {
    const minimize = button("whack-duel-window whack-duel-minimize", undefined, { type: "minimize" });
    minimize.setAttribute("aria-label", "最小化大厅");
    toolbar.append(minimize);
  }
  if (options.onExit) {
    const exit = button("whack-duel-window whack-duel-exit", undefined, { type: "exit" });
    exit.setAttribute("aria-label", "退出大厅");
    toolbar.append(exit);
  }
  if (trafficLog) {
    const logButton = element("button", "whack-duel-log-button", "调试");
    logButton.type = "button";
    const dialog = element("dialog", "whack-duel-log-dialog");
    dialog.setAttribute("aria-label", "调试");
    const header = element("div", "whack-duel-log-header");
    const heading = element("h2", null, "调试");
    const close = element("button", "whack-duel-log-close", "关闭");
    close.type = "button";
    close.addEventListener("click", () => dialog.close());
    header.append(heading, close);
    const log = element("pre", "whack-duel-log-content");
    const tools = element("div", "whack-duel-debug-actions");
    const inspect = button("whack-duel-log-close", "调用 JSQueryInitInfo", { type: "inspectAppUser" });
    const scan = button("whack-duel-log-close", "扫描原生桥", { type: "scanBridges" });
    inspect.addEventListener("click", () => { log.scrollTop = log.scrollHeight; });
    scan.addEventListener("click", () => { log.scrollTop = log.scrollHeight; });
    tools.append(inspect, scan);
    const logHeading = element("h3", "whack-duel-log-heading", "服务器通信日志");
    const clear = element("button", "whack-duel-log-clear", "清空日志");
    clear.type = "button";
    clear.addEventListener("click", () => trafficLog.clear());
    dialog.append(header, tools, logHeading, log, clear);
    trafficLog.subscribe((value) => { log.textContent = value || "暂无通信记录"; });
    logButton.addEventListener("click", () => { if (!dialog.open) dialog.showModal(); });
    toolbar.append(logButton);
    dialogs.push(dialog);
  }
  if (toolbar.childElementCount) lobby.prepend(toolbar);

  const hero = element("div", "whack-duel-hero");
  const logo = element("div", "whack-duel-logo");
  const icon = createGameIcon(element, options.iconUrl, "whack-duel-icon");
  const heading = element("h1", "whack-duel-heading", title);
  logo.append(icon);
  hero.append(logo, heading);

  const communityRoom = Boolean(options.communityRoom);
  const canAct = Boolean(options.onAction || communityRoom);

  const lineup = element("div", "whack-duel-lineup");
  const versus = element("div", "whack-duel-versus");
  const versusImage = element("img");
  versusImage.src = new URL("./assets/duel/versus.png", import.meta.url).href;
  versusImage.alt = "对战";
  versus.append(versusImage);

  let state = normalizeLobbyState({ players: [null, null], isHost: !communityRoom });
  let busy = false;

  function canCancelSeat(slot) {
    return communityRoom &&
      !state.isHost &&
      state.ready &&
      state.canReady &&
      slot === state.localSlot &&
      Boolean(state.players[slot]);
  }

  const seats = ["蓝方", "红方"].map((team, slot) => {
    const join = element("button", "whack-duel-seat");
    join.type = "button";
    join.addEventListener("click", () => {
      dispatch(canCancelSeat(slot) ? { type: "ready" } : { type: "join", slot });
    });
    join.dataset.slot = String(slot);
    join.setAttribute("aria-label", `加入${team}`);
    const info = element("div", "whack-duel-player-info");
    info.dataset.slot = String(slot);
    info.setAttribute("role", "status");
    const id = element("span", "whack-duel-player-id");
    const meta = element("div", "whack-duel-player-meta");
    const host = element("span", "whack-duel-player-host", "房主");
    const ready = element("span", "whack-duel-player-ready", communityRoom ? "已报名" : "已准备");
    meta.append(host, ready);
    info.append(id, meta);
    return { join, info, id, meta, host, ready, team };
  });
  lineup.append(seats[0].join, versus, seats[1].join);

  const details = element("div", "whack-duel-details");
  const roster = element("div", "whack-duel-roster");
  roster.append(seats[0].info, seats[1].info);
  details.append(roster);

  const controls = element("div", "whack-duel-controls");
  const readyButton = button("whack-duel-cta whack-duel-ready", communityRoom ? "报名" : "准备", { type: "ready" });
  const startButton = button("whack-duel-cta whack-duel-start", "开始对战", { type: "start" });
  controls.append(readyButton, startButton);
  const rules = element("section", "whack-duel-rules");
  const rulesText = element("p", "whack-duel-rules-text", options.rules);
  rules.append(element("h2", "whack-duel-rules-heading", "游戏规则"), rulesText);
  if (options.rules) details.append(rules);
  const error = element("p", "whack-duel-error");
  error.setAttribute("role", "alert");
  error.hidden = true;
  const startedLabel = "游戏已开始";
  const matchStatus = element("p", "whack-duel-match-status");
  matchStatus.setAttribute("role", "status");
  matchStatus.hidden = true;
  details.append(controls, matchStatus, error);
  layout.append(hero, lineup, details);

  const notice = element("dialog", "whack-duel-notice-dialog");
  const content = element("div", "whack-duel-started-content");
  const noticeHeading = element("h2");
  const closeNotice = element("button", "whack-duel-cta whack-duel-started-close", "知道了");
  closeNotice.type = "button";
  closeNotice.addEventListener("click", () => notice.close());
  notice.addEventListener("click", (event) => {
    if (event.target !== notice) return;
    const { left, right, top, bottom } = notice.getBoundingClientRect();
    if (event.clientX < left || event.clientX > right || event.clientY < top || event.clientY > bottom) {
      notice.close();
    }
  });
  content.append(noticeHeading, closeNotice);
  notice.append(content);
  dialogs.push(notice);

  function showNotice(kind, label) {
    notice.dataset.notice = kind;
    notice.setAttribute("aria-label", label);
    noticeHeading.textContent = label;
    if (notice.isConnected && !notice.open) notice.showModal();
  }

  function closeNoticeOfKind(kind) {
    if (notice.open && notice.dataset.notice === kind) notice.close();
  }

  function updateControls() {
    lobby.dataset.role = state.isHost ? "host" : "guest";
    for (const [slot, { join, ready, team }] of seats.entries()) {
      const player = state.players[slot];
      const cancelable = canCancelSeat(slot);
      const joinable = state.canJoin && !player;
      join.disabled = busy || !canAct || state.inProgress || (!joinable && !cancelable);
      if (cancelable) {
        join.dataset.cancelable = "true";
        join.setAttribute("title", "点击头像取消报名");
        join.setAttribute("aria-label", `取消${team}报名 ${player.name || player.id}`);
        ready.textContent = "点击头像取消报名";
      } else {
        delete join.dataset.cancelable;
        join.removeAttribute?.("title");
        ready.textContent = communityRoom ? "已报名" : "已准备";
      }
    }
    const hideReady = state.inProgress || (state.isHost && state.ready && !state.canReady) ||
      (!state.isHost && !state.ready && !state.canReady);
    readyButton.hidden = hideReady;
    readyButton.disabled = busy || !canAct || !state.canReady || hideReady;
    readyButton.setAttribute("aria-pressed", String(state.ready));
    readyButton.textContent = state.ready
      ? (communityRoom ? "取消报名" : "取消准备")
      : (communityRoom ? "报名" : "准备");
    startButton.hidden = state.inProgress || !state.isHost;
    startButton.disabled = busy || !canAct || startButton.hidden || !state.canStart || !state.players.every(Boolean);
    const visibleCount = Number(!readyButton.hidden) + Number(!startButton.hidden);
    controls.dataset.count = String(visibleCount);
    controls.hidden = visibleCount === 0;
  }

  function renderPlayers() {
    for (const [slot, { join, info, id, meta, host, ready, team }] of seats.entries()) {
      const player = state.players[slot];
      const label = player ? (player.name || player.id) : undefined;
      id.textContent = label ?? "等待玩家加入";
      host.hidden = !player?.isHost;
      ready.hidden = !player?.ready;
      meta.hidden = host.hidden && ready.hidden;
      if (player?.isHost) {
        join.dataset.host = "true";
        info.dataset.host = "true";
      } else {
        delete join.dataset.host;
        delete info.dataset.host;
      }
      join.setAttribute(
        "aria-label",
        player ? `${team}${player.isHost ? "房主" : "玩家"} ${label}` : `加入${team}`,
      );
      join.replaceChildren();
      if (!player) continue;
      const avatar = element("span", "whack-duel-avatar");
      avatar.setAttribute("aria-hidden", "true");
      avatar.append(element("span", undefined, Array.from(label.trim())[0].toUpperCase()));
      if (player.avatarUrl) {
        const image = element("img", "whack-duel-avatar-image");
        image.alt = "";
        image.addEventListener("error", () => image.remove(), { once: true });
        image.src = player.avatarUrl;
        avatar.append(image);
      }
      join.append(avatar);
    }
    updateControls();
  }

  renderPlayers();
  return {
    element: lobby,
    dialogs,
    updateBranding({ title: nextTitle, iconUrl, rules: nextRules }) {
      if (nextTitle) heading.textContent = nextTitle;
      if (iconUrl) icon.src = iconUrl;
      if (nextRules !== undefined) {
        rulesText.textContent = nextRules;
        if (nextRules) controls.before(rules);
        else rules.remove();
      }
    },
    update(nextState) {
      state = nextState;
      renderPlayers();
      const label = state.inProgress ? startedLabel : "";
      if (matchStatus.textContent !== label) matchStatus.textContent = label;
      matchStatus.hidden = !state.inProgress;
      if (!state.inProgress) closeNoticeOfKind("started");
    },
    showStarted() {
      showNotice("started", startedLabel);
    },
    showConnectionFailure() {
      showNotice("connection", "服务器连接失败");
    },
    clearConnectionFailure() {
      closeNoticeOfKind("connection");
    },
    setBusy(value) {
      busy = value;
      updateControls();
    },
    setError(message) {
      error.textContent = message;
      error.hidden = !message;
    },
  };
}
