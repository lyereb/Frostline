const defaultIcon = new URL("./assets/duel/game-icon.png", import.meta.url).href;

export function createGameIcon(element, iconUrl, className) {
  const icon = element("img", className);
  icon.alt = "游戏图标";
  icon.addEventListener("error", () => {
    if (icon.src !== defaultIcon) icon.src = defaultIcon;
  });
  icon.src = iconUrl || defaultIcon;
  return icon;
}
