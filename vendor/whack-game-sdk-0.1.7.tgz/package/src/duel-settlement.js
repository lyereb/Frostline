import { createGameIcon } from "./duel-brand.js";

const headings = {
  waiting: "等待对战结果",
  finished: "本局对战已结束",
  closed: "服务器已关闭",
};

const uploadLabels = {
  unavailable: "上传排行榜",
  ready: "上传排行榜",
  uploading: "上传中…",
  uploaded: "已上传",
};

export function createDuelSettlement(element, { title, iconUrl, actions, result }) {
  const { status, players, localSlot, scores, winnerSlot, summary, scoreUnit } = result;
  const panel = element("section", "whack-settlement");
  panel.dataset.status = status;
  const body = element("div", "whack-settlement-body");

  const brand = element("header", "whack-settlement-brand");
  const logo = element("div", "whack-settlement-logo");
  logo.append(createGameIcon(element, iconUrl, "whack-settlement-icon"));
  const state = element("p", "whack-settlement-status", headings[status]);
  state.setAttribute("role", "status");
  brand.append(logo, element("h1", "whack-settlement-title", title), state);

  const deck = element("div", "whack-settlement-deck");
  const message = element("div", "whack-settlement-message");
  const footer = element("div", "whack-settlement-footer");
  const feedback = element("p", "whack-settlement-feedback");
  feedback.setAttribute("role", "status");
  feedback.hidden = true;
  const submission = element("p", "whack-settlement-feedback");
  submission.setAttribute("role", "status");
  submission.hidden = true;
  const buttons = element("div", "whack-settlement-buttons");

  function playerCard(slot) {
    const player = players[slot];
    const card = element("div", "whack-settlement-card");
    card.dataset.slot = String(slot);
    const portrait = element("div", "whack-settlement-portrait");
    const avatar = element("span", "whack-settlement-avatar");
    avatar.setAttribute("aria-hidden", "true");
    if (player?.avatarUrl) {
      const image = element("img", "whack-settlement-avatar-image");
      image.alt = "";
      image.addEventListener("error", () => image.remove(), { once: true });
      image.src = player.avatarUrl;
      avatar.append(image);
    }
    portrait.append(avatar);
    if (status === "finished" && (winnerSlot === 0 || winnerSlot === 1)) {
      const won = slot === winnerSlot;
      card.dataset.outcome = won ? "win" : "loss";
      portrait.append(element("span", "whack-settlement-badge", won ? "胜" : "负"));
    }
    card.append(portrait, element("p", "whack-settlement-player-id", player?.name || player?.id || "玩家身份未知"));
    if (status !== "closed" && !summary) {
      const score = element("dl", "whack-settlement-score");
      const value = scores[slot];
      score.append(
        element("dt", null, slot === localSlot ? "你的得分" : "对手得分"),
        element("dd", null, Number.isFinite(value) && scoreUnit ? `${value} ${scoreUnit}` : value ?? "—"),
      );
      card.append(score);
    }
    return card;
  }

  function button(className, label, action) {
    const control = element("button", className, label);
    control.type = "button";
    control.addEventListener("click", action);
    return control;
  }

  deck.append(playerCard(localSlot));
  if (status === "closed") {
    const disconnected = element("span", "whack-settlement-disconnect");
    disconnected.setAttribute("aria-hidden", "true");
    deck.append(disconnected);
    message.append(element("p", null, "无法获取本局对战结果。"));
  } else if (status === "waiting") {
    const dots = element("span", "whack-settlement-dots");
    dots.setAttribute("aria-hidden", "true");
    message.append(dots, element("p", null, scores[localSlot] === undefined
      ? "正在获取你的得分，请稍候。"
      : "对手仍在游戏中，请稍候。"));
  }
  if (status !== "waiting") deck.append(playerCard(1 - localSlot));

  const upload = status === "closed" || summary ? null
    : button("whack-settlement-button whack-settlement-upload", uploadLabels.unavailable, actions.uploadSettlement);
  const retry = status === "waiting" && actions.retryCommunitySubmission
    ? button("whack-settlement-button whack-settlement-upload", "重试提交", actions.retryCommunitySubmission)
    : null;
  if (retry) {
    retry.hidden = true;
    buttons.append(retry);
  } else if (upload) buttons.append(upload);
  buttons.append(button(
    "whack-settlement-button whack-settlement-exit", summary ? "返回大厅" : "退出游戏", actions.exitSettlement,
  ));
  footer.append(feedback, submission, buttons);
  const belowDeck = element("div", "whack-settlement-details");
  if (message.childElementCount) belowDeck.append(message);
  if (summary) {
    const details = element("section", "whack-settlement-summary");
    details.append(element("h2", null, summary.title));
    if (summary.message !== undefined) details.append(element("p", null, summary.message));
    if (summary.rows?.length) {
      const list = element("dl", "whack-settlement-summary-rows");
      for (const { label, value } of summary.rows) {
        const row = element("div", "whack-settlement-summary-row");
        row.append(element("dt", null, label), element("dd", null, value));
        list.append(row);
      }
      details.append(list);
    }
    belowDeck.append(details);
  }
  belowDeck.append(footer);
  body.append(brand, deck, belowDeck);
  panel.append(body);

  return {
    element: panel,
    setUploadStatus(value, failed) {
      if (!upload) return;
      upload.disabled = value !== "ready";
      upload.textContent = uploadLabels[value];
      feedback.textContent = failed ? "上传失败，请重试。" : "";
      feedback.hidden = !failed;
    },
    setCommunitySubmission(state, message) {
      if (!retry) return;
      retry.hidden = state !== "failed";
      submission.hidden = false;
      submission.textContent = state === "submitting" ? "正在提交成绩…" : message;
    },
  };
}
