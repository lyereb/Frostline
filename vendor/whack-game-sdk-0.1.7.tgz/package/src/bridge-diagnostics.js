const bridgeName = /bridge|javascriptinterface|nativeinterface|^(?:android|reactnativewebview|jsinterface|nativeapp)$/i;
const maxBridges = 16;
const maxMethods = 8;
const appBridgeNames = ["WKWebViewJavascriptBridge", "whackGameBridge"];

function ownNames(object) {
  try {
    return Object.getOwnPropertyNames(object);
  } catch {
    return [];
  }
}

function prototypeOf(object) {
  try {
    return Object.getPrototypeOf(object);
  } catch {
    return null;
  }
}

function descriptorOf(object, name) {
  if (object == null) return undefined;
  try {
    return Object.getOwnPropertyDescriptor(object, name)
      ?? Object.getOwnPropertyDescriptor(prototypeOf(object) ?? {}, name);
  } catch {
    return undefined;
  }
}

function bridgeMethods(value) {
  const prototype = prototypeOf(value);
  const names = new Set(ownNames(value));
  if (prototype && prototype !== Object.prototype && prototype !== Function.prototype) {
    for (const name of ownNames(prototype)) names.add(name);
  }
  // Some native interfaces expose their methods without listing them as own properties.
  for (const name of ["JSQueryInitInfo", "postMessage", "callHandler"]) names.add(name);
  return [...names]
    .filter(name => name !== "constructor" && name.length <= 72 && typeof descriptorOf(value, name)?.value === "function")
    .slice(0, maxMethods);
}

export function scanAppBridges(host, pageUrl) {
  const entries = [];
  let truncated = false;

  function add(container, name, path) {
    const descriptor = descriptorOf(container, name);
    if (!descriptor) return;
    if (entries.length === maxBridges) {
      truncated = true;
      return;
    }
    // Accessor properties are reported as such without evaluating them.
    const value = descriptor.value;
    const type = "value" in descriptor ? (value === null ? "null" : typeof value) : "accessor";
    const entry = { path, type };
    if (type === "object" || type === "function") {
      const methods = bridgeMethods(value);
      if (methods.length) entry.methods = methods;
    }
    entries.push(entry);
  }

  for (const name of appBridgeNames) add(host, name, `window.${name}`);
  const webkit = descriptorOf(host, "webkit");
  const handlerDescriptor = descriptorOf(webkit?.value, "messageHandlers");
  if (handlerDescriptor) {
    const handlers = handlerDescriptor.value;
    const names = new Set(["whackGameBridge", ...ownNames(handlers)]);
    const firstHandler = entries.length;
    for (const name of names) {
      if (name.length <= 72) add(handlers, name, `window.webkit.messageHandlers.${name}`);
    }
    if (entries.length === firstHandler) add(webkit.value, "messageHandlers", "window.webkit.messageHandlers");
  } else if (webkit?.get) {
    add(host, "webkit", "window.webkit");
  }
  add(descriptorOf(host, "chrome")?.value, "webview", "window.chrome.webview");

  for (const name of ownNames(host)) {
    if (!appBridgeNames.includes(name) && name.length <= 72 && bridgeName.test(name)) {
      add(host, name, `window.${name}`);
    }
  }

  return { origin: pageUrl ? new URL(pageUrl).origin : undefined, bridges: entries, truncated };
}
