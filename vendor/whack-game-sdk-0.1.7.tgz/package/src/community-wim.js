function parseJsonMaybe(value) {
  if (typeof value !== "string") return value;
  return JSON.parse(value);
}

function sameDecimalId(value, expected) {
  if (value === undefined || value === null) return false;
  const text = Number.isSafeInteger(value) ? String(value) : String(value);
  return text === expected;
}

export function createCommunityWimClient({
  url, roomId, playerId, token, WebSocketImpl = globalThis.WebSocket, log,
  onStatus, onJoined, onEvent, onReleased, onError,
}) {
  if (typeof WebSocketImpl !== "function") {
    throw new Error("WebSocket is not available in this environment");
  }
  const baseUrl = url instanceof URL ? new URL(url.href) : new URL(url);
  const logUrl = `${baseUrl.origin}${baseUrl.pathname}`;
  let socket;
  let status = "idle";
  let joined = false;
  let released = false;
  let joinTimer;

  function setStatus(next, error) {
    if (status === next) return;
    status = next;
    if (next !== "connecting") clearTimeout(joinTimer);
    log?.write("WIM 连接状态", { status: next, room_id: roomId });
    onStatus?.(next, error);
  }

  function sendRaw(current, message) {
    if (socket !== current || current.readyState !== WebSocketImpl.OPEN) return false;
    log?.write("WIM 发送", message);
    current.send(JSON.stringify(message));
    return true;
  }

  function handleMessage(current, raw) {
    if (socket !== current) return;
    let envelope;
    try {
      const text = typeof raw === "string"
        ? raw
        : new TextDecoder().decode(raw instanceof ArrayBuffer ? new Uint8Array(raw) : raw);
      envelope = JSON.parse(text);
    } catch (error) {
      onError?.(new Error("WIM 消息 JSON 解析失败", { cause: error }));
      return;
    }
    log?.write("WIM 接收", envelope);

    const { type, payload } = envelope ?? {};
    if (type === "connection.ready") {
      if (payload?.user_id !== undefined && playerId && !sameDecimalId(payload.user_id, playerId)) {
        closeSocket(new Error("WIM 连接用户与当前玩家不匹配。"));
        return;
      }
      try {
        sendRaw(current, { type: "room.join", payload: { room_id: roomId } });
      } catch (error) {
        closeSocket(error);
      }
      return;
    }

    if (type === "room.joined") {
      if (payload?.room_id !== roomId) return;
      joined = true;
      setStatus("open");
      onJoined?.();
      return;
    }

    if (type === "room.left") {
      if (payload?.room_id === roomId) joined = false;
      return;
    }

    if (type === "room.released") {
      if (payload?.room_id !== roomId) return;
      released = true;
      closeSocket();
      onReleased?.();
      return;
    }

    if (type === "message.created") {
      const message = payload?.message;
      if (!message || message.room_id !== roomId) return;
      let content;
      let eventData;
      try {
        content = parseJsonMaybe(message.content);
        if (!content || typeof content !== "object" || typeof content.event !== "string") {
          return;
        }
        eventData = content.data === undefined ? undefined : parseJsonMaybe(content.data);
      } catch (error) {
        onError?.(new Error("WIM 房间事件解析失败", { cause: error }));
        return;
      }
      onEvent?.({ event: content.event, data: eventData, message });
    }
  }

  function connect() {
    if (released || socket) return false;
    const connectUrl = new URL(baseUrl.href);
    connectUrl.searchParams.set("token", token);
    log?.write("WIM 连接", { url: logUrl, room_id: roomId });
    setStatus("connecting");

    let current;
    try {
      current = new WebSocketImpl(connectUrl.href);
    } catch (error) {
      setStatus("closed", error);
      return false;
    }
    socket = current;
    joined = false;
    joinTimer = setTimeout(() => closeSocket(new Error("WIM 加入聊天室超时。")), 10000);

    current.addEventListener("message", ({ data }) => handleMessage(current, data));
    current.addEventListener("error", () => {
      if (socket === current) closeSocket(new Error("WIM WebSocket 连接错误。"));
    });
    current.addEventListener("close", ({ code }) => {
      if (socket !== current) return;
      socket = undefined;
      joined = false;
      const detail = Number.isInteger(code) ? `（关闭码 ${code}）` : "";
      setStatus("closed", new Error(`WIM WebSocket 连接已断开${detail}。`));
    });
    return true;
  }

  function disconnect() {
    const current = socket;
    if (joined && !released && current?.readyState === WebSocketImpl.OPEN) {
      try {
        sendRaw(current, { type: "room.leave", payload: { room_id: roomId } });
      } catch {
        // Best-effort leave before closing socket.
      }
    }
    closeSocket();
  }

  function closeSocket(error) {
    const current = socket;
    socket = undefined;
    joined = false;
    try {
      current?.close();
    } catch {
      // Ignore close failures on teardown.
    }
    setStatus("closed", error);
  }

  return {
    connect,
    disconnect,
    get status() { return status; },
    get joined() { return joined; },
    get released() { return released; },
  };
}
