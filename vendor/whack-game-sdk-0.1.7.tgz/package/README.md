# 网页游戏 SDK 接入指南

适用版本 0.1.7。SDK 提供服务器通信入口、游戏大厅和结算页。每个游戏实现进入玩法与停止玩法两个回调。社群 PK 的游戏 ID 由开局链接提供。

## 本地体验

在 SDK 项目目录运行 `npm run demo`，打开[本地演示](http://127.0.0.1:4173)。点击蓝方和红方席位，确认头像和玩家 ID 出现，再点「准备」和「开始对战」。演示在同一页面模拟两个玩家和服务端。命中目标三次可结束本局，也可以在进行中由模拟服务器强制结束。

也可以直接预览[等待结果](http://127.0.0.1:4173/?settlement=waiting)、[对战结束](http://127.0.0.1:4173/?settlement=finished)和[服务器关闭](http://127.0.0.1:4173/?settlement=closed)。完整演示里，命中三次后先显示自己的得分，六秒后由模拟服务器下发双方成绩。

运行 `npm test` 可验证局生命周期和断线恢复。演示和测试需要 Node.js 22 或更新版本。SDK 本身运行在支持 ES 模块、WebSocket 和 AbortController 的现代浏览器中。

## 安装和初始化

在 SDK 项目目录执行 `npm pack` 生成 `whack-game-sdk-0.1.7.tgz`。游戏项目可以执行 `npm install <压缩包路径>`，再通过现有前端构建工具引入 SDK。原生浏览器项目也可以将 `src/` 发布为静态资源，通过相对路径引入 `index.js` 和 `styles.css`。

新游戏接入时，将 [打包游戏.cmd](./打包游戏.cmd) 复制到游戏项目根目录。游戏的初始版本默认为 `"1.00"`，可在自己的 `sdk.config.json` 中设置。发布目录和双击打包的用法见[统一打包与游戏版本](#统一打包与游戏版本)。

### 从配置文件初始化

把包中的 `sdk.config.example.json` 复制到游戏的静态目录并命名为 `sdk.config.json`，填写默认标题、规则和图标。将 JSON 文件与游戏网页一起部署。独立模式使用配置中的 `gameId`，参见 `demo/sdk.config.json`。

```json
{
  "version": "1.00",
  "title": "巅峰对决",
  "lobby": {
    "mode": "duel",
    "rules": "双方准备后开始对战。\n率先达成目标者获胜。",
    "iconUrl": "./assets/game-icon.png"
  }
}
```

调用 `createGameSdkFromConfig()` 加载配置，再启动 SDK。 `game`、`transport`、大厅操作和结算回调继续使用游戏提供的实现。

```js
import { createGameSdkFromConfig } from "whack-game-sdk";
import "whack-game-sdk/styles.css";

const sdk = await createGameSdkFromConfig({
  root: document.querySelector("#game-root"),
  configUrl: "./sdk.config.json",
  game,
  transport,
  lobby: { onAction: handleLobbyAction },
  onMessage: handleServerMessage,
  settlement: { onUpload: uploadScore },
});

sdk.start();
```

`configUrl` 默认为页面同目录的 `./sdk.config.json`。相对的 `iconUrl` 以配置文件所在目录为基准，原游戏包里可从浏览器访问的图片可以直接复用。更新已部署的 JSON 后刷新网页即可应用。找不到文件、JSON 格式有误或配置字段非法时，初始化 Promise 会拒绝，宿主可以显示错误并停止启动。

### 社群 PK 房间信息

社群 PK 页面链接示例为 `https://game.example.com/index.html?chat_room_id=G_123456&group_id=0&game_id=31`。SDK 支持开局卡片的 `chat_room_id` 和既有链接的 `id`，并以 `chat_room_id` 写入 HTTP 表单。链接中的 `game_id` 同时用作 SDK 的游戏 ID。群 ID `0` 表示外部场次。

只提供社群 PK 的游戏可以在初始化时传入 `requireCommunityRoom: true`。缺少房间参数、参数无效或大厅配置加载失败时，SDK 仍显示大厅，并弹出「服务器连接失败」。查房或 WIM 连接失败也使用这个弹窗。关闭后可通过大厅右上角的「调试」定位失败环节，登录凭证会隐藏。

SDK 在取得 App 用户资料后，用原生返回的 `auth_token` 作为 Bearer JWT，向 `/games/room/info` 发送表单 POST 请求。表单携带 `group_id`、`game_id` 和 `chat_room_id`。API 默认使用网页同源地址。跨域 API 可在 `sdk.config.json` 中设置 `"roomApiBaseUrl": "https://api.example.com"`，指向部署环境的实际 API 主机，服务端需允许游戏网页来源和 `Authorization` 请求头。社群 PK 模式可独立运行，此时初始化可省略 `transport`。

获取房间信息成功后，SDK 会使用原生返回的 `im_token` 连接 WIM WebSocket 聊天室（默认推导自 API 主机的 `/ws`，也可在 `sdk.config.json` 或初始化参数中设置 `"roomWsUrl": "wss://wim.example.com/ws"` 或测试环境的 `"ws://<wim-host>:13001/ws"`）。握手收到 `connection.ready` 后自动发送 `room.join`，收到 `room.joined` 后实时处理 `game_room_apply`、`game_room_unapply`、`game_start`、`whackgroup:game_pk_result` 及 `room.released` 事件。断线重连重新加入聊天室后会自动再次调用 `/games/room/info` 恢复最新房间状态；销毁 SDK 时自动发送 `room.leave` 并断开连接。

成功后，SDK 更新大厅的游戏名称、图标、规则和玩家席位，并按服务器的 `players[].status` 显示准备状态，同时根据 `creator.user_id` 区分房主与非房主：

- 房主座位会标记「房主」（一般默认坐在左侧 1 号位），已报名后不可取消报名，不显示取消报名按钮，点击自己头像也不会取消。
- 只有房主显示「开始对战」按钮；双人模式（`duel`）必须两个位置都坐满后才允许点击开始。
- 非房主不显示「开始对战」按钮，可点击空位调用 `POST /games/room/apply` 报名，报名后可直接点击自己头像（或底部「取消报名」按钮）取消报名。
- 房主点击「开始对战」时，若宿主未自定义 `lobby.onAction`，SDK 自动调用 `POST /games/room/start`；收到 WIM 聊天室的 `game_start` 广播后，全体已报名玩家共同调用 `game.start(...)` 进入 PK 玩法。
- 未入席的用户收到开局广播时留在大厅并看到「游戏已开始」弹窗。点击弹窗外侧或「知道了」即可关闭，房间处于比赛中时大厅持续显示「游戏已开始」。中途打开房间时也会从服务器房间状态显示该提示。

可以用 `sdk.getRoomInfo()` 读取已加载的房间数据，其中包含 `creator` 与 `result_rules`。请求失败会显示大厅提示，并通过 `onError(error, "fetchRoomInfo")` 或 `onError(error, "lobbyAction")` 上报。页面销毁会取消未完成的请求并清除房间登录凭证。

社群 PK 的玩法结束时调用 `context.finish({ scores: [{ type: "MAX_SCORE", score: 920 }] })`。
游戏需要按规则计算成绩，SDK 会核对每项 `result_rules[].rule_code` 都有对应的数值，然后使用当前玩家的 JWT
向 `POST /games/room/result` 提交 `completed=true` 和 `scores`。提交失败会在等待页显示错误并允许重试。
等待页展示本人成绩，最终成绩和胜负来自 WIM 的 `whackgroup:game_pk_result` 广播。

大厅右上角的「调试」显示 SDK 房间 HTTP 请求与响应、传输层连接状态以及收发消息。日志保存在当前页面内存中，最多保留 100 条，可以在面板中清空。登录令牌和密码等字段会隐藏。

在调试面板里点击「调用 JSQueryInitInfo」，SDK 会即时调用当前 WebView 的原生桥。成功时日志记录用户 ID、昵称、头像和凭证是否存在。失败时日志指出桥、方法或返回数据的具体问题。

点击「扫描原生桥」可在日志里对照当前页面来源、`window` 上的桥对象以及 `webkit.messageHandlers`、`chrome.webview`。结果只显示对象路径、类型和可识别的方法名，访问器会标为 `accessor`。

### 从代码初始化

页面提供一个专用容器，例如 `<div id="game-root"></div>`。以下示例默认进入固定的「点击挑战」玩法，第三次命中时申请结束。示例使用 JSON 直传，运行前需填写自己的服务器地址并匹配其协议。

```js
import { createGameSdk, createWebSocketTransport } from "whack-game-sdk";
import "whack-game-sdk/styles.css";

let removeHitListener;
const sdk = createGameSdk({
  root: document.querySelector("#game-root"),
  gameId: "your-game-id",
  title: "游戏大厅",
  transport: createWebSocketTransport({
    url: "wss://game.example.com/ws",
    protocol: {
      encode: (message) => JSON.stringify(message),
      decode: (data) => JSON.parse(data),
    },
  }),
  game: {
    start({ container, finish }) {
      const button = document.createElement("button");
      button.textContent = "击中目标";
      let hits = 0;
      function hit() {
        hits += 1;
        button.textContent = `命中 ${hits} / 3`;
        if (hits === 3) finish({ hits });
      }
      button.addEventListener("click", hit);
      removeHitListener = () => button.removeEventListener("click", hit);
      container.append(button);
    },
    stop() {
      removeHitListener?.();
      removeHitListener = undefined;
    },
  },
  onError(error, operation) {
    console.error(operation, error);
  },
});

sdk.start();
// 宿主页面卸载时调用 sdk.destroy()。
```

## 统一打包与游戏版本

1. 将 SDK 根目录的 [打包游戏.cmd](./打包游戏.cmd) 复制到游戏项目根目录。文件使用 Windows 自带的 PowerShell 和 .NET 压缩功能，单独复制这一个文件即可运行。
2. 在游戏自己的 `sdk.config.json` 中维护版本，省略 `version` 时使用 `"1.00"`。构建游戏，确认发布目录中已经有 `index.html`。默认读取项目根目录的 `sdk.config.json`，发布目录默认为 `dist`，ZIP 输出到 `release/Game.zip`。
3. 双击复制过来的 `打包游戏.cmd`。脚本会生成 `dist/version.json`，初始内容为 `{"version":"1.00"}`。ZIP 中的 `version.json` 和 `index.html` 同级，上传后将 ZIP 解压到服务器的静态站点目录即可。

游戏使用其他目录时，修改复制件顶部的 `WHACK_PACK_CONFIG`、`WHACK_PACK_SOURCE` 或 `WHACK_PACK_ARCHIVE`。这些路径以复制件所在目录为基准，ZIP 放在发布目录外。配置在 `public/sdk.config.json` 的游戏，将 `WHACK_PACK_CONFIG` 改成该路径即可。

需要双击时一并构建的游戏，可以取消脚本顶部 `call npm.cmd run build || goto done` 那一行的注释，或换成游戏实际的构建命令。自动化中可执行 `打包游戏.cmd --no-pause`。配置有误、发布目录缺少入口或压缩失败时，脚本会报错并保留已有 ZIP。

每次发版前更新游戏配置里的 `version` 即可。SDK npm 包的版本由 SDK 自己的 `package.json` 管理。

## 双人对战大厅

在 `createGameSdk` 中传入 `lobby` 配置。当前模式为 `duel`，省略 `mode` 时也显示双人大厅。通过 SDK 顶层的 `title` 配置游戏标题，例如 `title: "点击挑战"`。标题显示在图标下方。

大厅铺满当前浏览器视口。双人席位在中央，图标、标题、规则和操作区围绕席位居中排列，矮窗口采用紧凑间距并支持滚动。为支持手机刘海和底部手势区，请在宿主 HTML 添加 `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">`。建议将 SDK 容器直接放在页面级布局中，避免放入带 `transform` 或 `contain: paint` 的祖先元素。

```js
lobby: {
  mode: "duel",
  iconUrl: "/assets/my-game.png",
  rules: "双方入席并准备后开始对战。\n率先达成目标者获胜。",
  onAction(action) {
    return roomAdapter.handle(action);
  },
}
```

省略 `iconUrl` 时显示 SDK 的默认游戏图标。 `rules` 支持换行，以纯文本显示，较长的规则可在规则栏内滚动。可选的 `onMinimize`、`onExit` 由宿主实现窗口行为，配置后才显示对应按钮。

大厅通过 `onAction` 抛出本地操作意图。 `{ type: "join", slot: 0 }` 表示加入蓝方，`slot: 1` 表示加入红方。 `{ type: "ready" }` 表示切换准备状态，`{ type: "start" }` 表示申请开局。适配层取得房间状态后调用 `sdk.updateLobby(state)`。 `onAction` 可返回 Promise，等待期间会禁用席位和准备、开局按钮。开局仍由现有的 `round.start` 消息触发。

```js
sdk.updateLobby({
  players: [
    { id: "player-01", avatarUrl: "/avatars/player-01.png", ready: false },
    null,
  ],
  canReady: true,
  ready: false,
  canStart: false,
});
```

每次更新传入包含两个席位的 `players`。空席使用 `null`，已占用席位使用带字符串 `id` 的玩家对象。`name`、`avatarUrl`、席位的 `ready` 与 `isHost` 可省略；提供 `name` 时优先展示昵称，头像缺失或加载失败时使用名称或 ID 首字符。大厅状态的 `isHost`（默认为 `true`）控制是否显示「开始对战」按钮，非房主隐藏该按钮；`ready` 决定准备按钮显示「准备/报名」或「取消准备/取消报名」，房主已报名且 `canReady` 为 `false` 时隐藏取消按钮。两席均有人且 `isHost` 与 `canStart` 均为真时可申请开局。这里的操作和状态是 SDK 的本地接口，服务端协议确定后可由适配层进行映射。

## 游戏生命周期

1. 调用 `sdk.start()` 后，SDK 显示大厅并建立连接。每次连接成功后都会发送 `game.join`，携带当前游戏的 `gameId`。
2. 服务器发来匹配的 `round.start` 后，SDK 创建本局专用容器并调用 `game.start(context)`。游戏在此回调中进入自己的固定玩法或关卡，可从 `context.payload` 读取本局参数。
3. 游戏达到本地结束条件时调用 `context.finish(data)`。服务端也可用 `round.forceEnd` 结束当前局。SDK 在两条路径上都会停止游戏并展示等待结算页。使用自定义传输时，本地结束会发送 `round.finish`，其中 `data` 由游戏定义；社群 PK 使用上面的成绩提交方式。
4. SDK 收到当前局的双人结算消息后更新页面。最终结果先于结束信号到达时，SDK 会先停止游戏再显示结果。玩家点击「退出游戏」后离开本局，默认回到大厅。

`game.start(context)` 的参数包括 `container`、`gameId`、`roundId`、`payload`、`signal`、`finish(data)` 和 `send(type, payload)`。本局首次调用 `finish` 返回 `true`，结束后的调用返回 `false`。如果玩法初始化抛错或返回的 Promise 拒绝，SDK 会报告错误、停止本局并向服务器发送原因 `game-error`，随后等待结算。

`game.stop({ roundId, reason })` 同步释放本局的资源，例如帧循环、计时器、输入监听及引擎实例。原因值有 `game`、`server`、`result`、`game-error` 或 `destroy`。SDK 先中止本局的 `signal` 再调用 `stop`。若 `start` 包含异步加载，应将 `signal` 传给支持取消的操作，并在每次异步恢复后检查 `signal.aborted`，防止迟到的加载重新启动旧局。

`sdk.start()` 每个实例可调用一次。 `sdk.destroy()` 清理当前玩法、界面和连接，页面重新挂载时创建新实例。一个 SDK 实例持有一个游戏 ID、一个页面容器和一个独立的传输实例。

## 双人结算

结算沿用顶层的 `title` 和 `lobby.iconUrl`，并在开局时记录 `sdk.updateLobby` 提供的两个席位。用 `localSlot: 0` 或 `localSlot: 1` 指明当前玩家，默认为蓝方 `0`。双方结算中，本人在左，对手在右。各状态均可通过 `payload.players` 补充或纠正本局的头像与 ID，席位顺序为蓝方、红方。

继续使用 `round.result`，将正式协议映射为下面的 SDK 内部数据。

- 等待对手结束时传 `{ status: "waiting", score: "1,280" }`。该消息在本局进入等待结算后生效，确认本人的分数并结束客户端的完成消息重发。
- 双方结束后传 `{ status: "finished", scores: ["1,280", "1,060"], winnerSlot: 0 }`。双方使用同一个结算页面。可选的 `winnerSlot` 为 `0` 或 `1` 时显示胜负角标，为 `null` 或省略时使用普通卡片。分数支持字符串或有限数字，按服务端给出的内容直接展示。
- 服务端确认本局结果不可获取时传 `{ status: "closed" }`。页面显示「服务器已关闭」，保留玩家头像与 ID，只提供退出操作。临时 WebSocket 断开沿用原有重连流程。

在创建 SDK 时可配置 `settlement.onUpload({ gameId, roundId, playerId, score, status })` 对接排行榜。等待与最终状态都可以上传已经返回的本人分数。回调可返回 Promise，成功后显示「已上传」，失败后可重试。可选的 `settlement.onExit({ gameId, roundId, status })` 在离开本局后通知宿主。

## 在原生 App 的 WebView 中接入

网页通过 `createAppBridge()` 调用 App 提供的原生方法。传入 `appBridge` 后，SDK 会在检测到可用通道时接通大厅和结算页的退出操作。游戏服务器继续使用现有的 `transport`。在普通浏览器里，结算的「退出游戏」仍默认返回大厅。

```js
import { createAppBridge, createGameSdkFromConfig } from "whack-game-sdk";

const appBridge = createAppBridge();
const sdk = await createGameSdkFromConfig({ root, game, transport, appBridge });
sdk.start();

// 宿主卸载页面时调用 sdk.destroy() 和 appBridge.destroy()。
```

大厅退出调用 `closeGame`，参数为 `{ gameId, source: "lobby" }`。结算退出额外提供 `roundId` 和 `status`，其中 `source` 为 `"settlement"`。显式传入的 `lobby.onExit` 或 `settlement.onExit` 优先生效。App 有既有桥时，可传入提供 `available` 和异步 `call(method, params)` 的适配对象。

### 原生入口与消息约定

- Android 在加载网页前通过 `WebViewCompat.addWebMessageListener` 注册 `whackGameBridge`，检查 `WEB_MESSAGE_LISTENER` 支持情况，并限定受信任的 HTTPS 来源和主页面。用当前请求的 `JavaScriptReplyProxy.postMessage` 回传 JSON 字符串。[Android WebViewCompat 文档](https://developer.android.com/reference/androidx/webkit/WebViewCompat)
- iOS 在创建 `WKWebView` 时通过 `WKUserContentController` 注册同名的 `WKScriptMessageHandlerWithReply`，网页主环境使用 `WKContentWorld.page`。收到消息时核对 `frameInfo` 的主页面和来源，并通过 `replyHandler` 返回 JSON 字符串。[Apple WebKit 文档](https://developer.apple.com/documentation/webkit/wkscriptmessagehandlerwithreply)

两端都接收 JSON 字符串。原生端按明确支持的方法处理，在应答里原样返回请求的字符串 `id`。

```json
{"id":"whack-1","method":"closeGame","params":{"gameId":"your-game-id","source":"lobby"}}
```

成功应答可以带可选的 `result`。

```json
{"id":"whack-1","ok":true}
```

失败应答包含 `error.message` 和可选的错误码。

```json
{"id":"whack-1","ok":false,"error":{"code":"BUSY","message":"当前无法关闭游戏"}}
```

原生端处理 `closeGame` 时先回应请求，再关闭当前游戏 WebView。App 也可以实现额外的方法，例如在游戏有登录要求时提供 `getLaunchContext`。网页可在 `sdk.start()` 前调用 `await appBridge.call("getLaunchContext")`，再用返回的启动信息初始化游戏通信。

`appBridge.available` 表示当前页面检测到了原生通道，`platform` 为 `android`、`ios` 或 `null`。调用默认等待 5000 毫秒，可以通过 `createAppBridge({ timeoutMs })` 调整。失败时 Promise 拒绝，错误的 `code` 可用于区分未接入、超时、无效回复和原生返回的错误。卸载时调用 `destroy()` 清理监听并结束等待中的请求。

### 读取现有 Android 桥的玩家信息

SDK 支持 `window.WKWebViewJavascriptBridge.JSQueryInitInfo` 和 `window.Android.JSQueryInitInfo`，按上述顺序选择可用方法。在 `sdk.start()` 完成大厅和通信启动后，SDK 无参数调用该方法一次，解析同步返回的 JSON 字符串。若桥在启动时还未注入，SDK 会在页面 `load` 时再检查。调试面板使用同一选择顺序，并显示实际使用的桥。

```js
const sdk = await createGameSdkFromConfig({
  root,
  game,
  transport,
  onAppUser(profile) {
    // profile.id、profile.nickname、profile.avatarUrl 可供入席等逻辑使用。
    updateLocalPlayer(profile);
  },
});

sdk.start();
const profile = sdk.getAppUser();
```

资料中的 `id` 映射自 `user.user_id`，昵称优先使用 `nick_name`，再用 `nickname`。头像优先使用 `head_img`，再用 `avatar`。昵称或头像为空时返回空字符串。`getAppUser()` 在尚未取得资料时返回 `null`，也会检查是否有刚注入的桥。成功时 `onAppUser` 回调一次。SDK 仅保留这三项，并在销毁时清除。社群 PK 查询房间时短暂使用原生响应中的 `auth_token` 进行 HTTP 鉴权。解析失败通过 `onError(error, "queryAppInitInfo")` 报告，游戏大厅仍正常启动。

完整字段名、数据类型和参考含义见 [JSQueryInitInfo 原生用户数据字段](docs/native-app-init-info.md)。

### 普通浏览器与游客登录

普通浏览器没有宿主桥时，`sdk.getAppUser()` 返回 `null`，大厅按默认流程启动。游戏可以传入 `onGuestRequired({ gameId })`，将来在这个回调里接上自己的游客登录页。

```js
const sdk = await createGameSdkFromConfig({
  root,
  game,
  transport,
  onGuestRequired({ gameId }) {
    // 游客登录页上线后，在这里根据 gameId 跳转。
  },
});
sdk.start();
```

SDK 在页面加载完成后检查宿主，每个实例最多触发一次回调。现有 Android 初始化桥、SDK 的 Android 或 iOS 通道，以及接入方传入的可用 `appBridge` 都能识别为宿主。App 应在页面加载完成前注入桥。宿主用户资料读取失败会通过错误回调报告，游客入口只在未检测到宿主时触发。

## 通信与协议适配

SDK 内部使用 `{ type, gameId, roundId?, payload? }` 表示消息。下列消息名和字段用于描述 SDK 的接口。正式服务器协议确定后，在 `protocol.encode(message)` 和 `protocol.decode(data)` 中映射到实际格式。

**客户端发送**

- `game.join` 携带 `gameId`，表示此连接希望接收哪个游戏的消息。
- `round.finish` 携带 `gameId`、`roundId` 和 `payload`。正常结束的 `payload` 为 `{ reason: "game", data }`，启动失败时为 `{ reason: "game-error" }`。

**服务器发送**

- `round.start` 携带 `gameId`、`roundId` 和可选的 `payload`。每个实例生命周期内 `roundId` 唯一，重连时继续使用当前局原有 ID。SDK 在大厅内接受新的开局消息。
- `round.forceEnd` 携带 `gameId` 和 `roundId`，随后由服务器发送该局的 `round.result`。
- `round.result` 携带 `gameId`、`roundId` 和结算内容 `payload`。双人结算使用上面的状态格式。已有游戏仍可传通用结果 `{ title, message?, rows? }`，其中 `rows` 的 `label` 为字符串，`value` 为字符串或有限数字。

以下是使用示例 JSON 适配器时的结算消息。

```json
{
  "type": "round.result",
  "gameId": "your-game-id",
  "roundId": "round-42",
  "payload": {
    "title": "本局完成",
    "message": "成绩已由服务器确认",
    "rows": [{ "label": "得分", "value": 120 }]
  }
}
```

服务端消息必须携带 `gameId`。SDK 按游戏 ID 和当前局 ID 过滤开局、结束与结算事件，同一局的开局和最终结算各生效一次。结算字段以纯文本渲染。

游戏可以用 `sdk.send(type, payload)` 发送游戏级自定义消息，用 `context.send(type, payload)` 发送自动带有当前局 ID 的自定义消息。五个 SDK 控制消息名为保留字。发送前须已连接，局级发送还要求玩法进行中。可选的 `onMessage(message)` 接收匹配当前游戏的自定义消息，带 `roundId` 的消息只会转发给正在进行的匹配局。以上发送方法在连接或编码失败时抛出错误。

WebSocket 适配器的 `encode` 返回浏览器 WebSocket 支持的消息数据。 `decode` 接收文本或 `ArrayBuffer`，返回 SDK 消息，或返回 `null` 跳过由适配层处理的消息。也可以提供自定义传输对象，实现 `connect({ onStatus, onMessage, onError })`、同步 `send(message)` 和 `disconnect()`。连接可发送时上报 `onStatus("open")`，连接关闭时上报 `onStatus("closed")`，收到消息时调用 `onMessage(message)`。发送失败通过抛错报告，连接或解码错误通过 `onError(error)` 报告。

## 断线与重连

断线会在 SDK 界面显示「重新连接」。宿主也可调用 `sdk.reconnect()`，它在断线或结束消息发送失败时发起一次连接尝试，返回是否发起。进行中的玩法继续由游戏控制。等待结算中的本地结束消息会在每次重连并发送 `game.join` 后重发一次，直到收到服务端强制结束或结算。

服务端接入时需按会话和 `roundId` 幂等处理 `round.finish`，并在重连后能补发该局结果。当前版本的等待状态存在页面内存里。正式联调时需确定服务器地址与鉴权方式、消息映射、回合标识和重连补发约定。
