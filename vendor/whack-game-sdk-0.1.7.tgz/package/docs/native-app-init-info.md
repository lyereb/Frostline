# JSQueryInitInfo 原生用户数据字段

`JSQueryInitInfo()` 可以挂在 `window.WKWebViewJavascriptBridge` 或 `window.Android` 上，SDK 无参数调用并读取同步返回的 JSON 字符串。解析后的顶层包含 `client` 和 `user` 两个对象。以下类型来自已收到的返回结构，字段必填性、状态枚举和时间单位以原生及服务端协议为准。

## SDK 提供的玩家资料

- `id` 是字符串，来自 `user.user_id`。
- `nickname` 是字符串，优先取 `user.nick_name`，其次取 `user.nickname`。
- `avatarUrl` 是字符串，优先取 `user.head_img`，其次取 `user.avatar`。

SDK 只保留这三项，通过 `onAppUser(profile)` 和 `sdk.getAppUser()` 提供。缺失的昵称或头像返回空字符串。社群 PK 房间 HTTP 接口（查询房间信息、报名/取消报名、开始游戏）使用 `user.auth_token` 进行鉴权，WIM WebSocket 聊天室使用 `user.im_token` 进行鉴权，均在页面销毁时清除。

## 客户端信息 client

- `from`（字符串）客户端来源或渠道。
- `imei`（字符串）设备标识字段，生成方式以原生协议为准。
- `locale`（字符串）客户端语言或地区标识。
- `version`（字符串）App 版本。

## 用户信息 user

### 用户身份与展示资料

- `user_id`（字符串）用户 ID。
- `nick_name`（字符串）昵称。
- `nickname`（字符串）另一个昵称字段。
- `head_img`（字符串）头像地址。
- `avatar`（字符串）另一个头像字段。
- `user_desc`（字符串）个人简介。
- `birthday`（字符串）生日。
- `age`（数字）年龄字段。
- `gender`（数字）性别枚举。
- `city`（字符串）城市或地区展示值。
- `fans_count`（数字）粉丝数量。
- `ic_list`（字符串数组）用户标签列表。

### 账号、联系方式与设置

- `mobile`（字符串）手机号字段。已收到的返回为掩码格式。
- `email`（字符串）邮箱字段。
- `qq`（字符串）QQ 账号字段。
- `wechat`（字符串）微信账号字段。
- `alipay`（布尔值）支付宝相关状态。
- `bind_flag`（数字）绑定状态标记。
- `check_id`（字符串）校验相关标识，具体用途待确认。
- `real_verify`（布尔值）实名认证状态。
- `loginType`（数字）登录类型。
- `reg_timestamp`（数字）注册时间字段。
- `teen_mode_locked`（布尔值）青少年模式锁定状态。
- `isStealthVisit`（布尔值）隐身访问状态。

### 登录凭证

- `auth_token`（字符串）登录凭证。
- `im_token`（字符串）即时通信凭证。
- `password`（字符串）密码相关字段。已收到的返回为掩码格式。
- `expire_at`（数字）过期时间字段，作用对象及单位待确认。

### 业务档案与状态

- `created_group_count`（数字）已创建的群组数。
- `flash_match_profile_id`（数字）快速匹配业务档案 ID。
- `profile_id`（字符串）档案 ID。
- `group_type`（数字）群组类型。
- `role`（数字）角色枚举。
- `online`（数字）在线状态。
- `step`（数字）流程步骤字段，业务含义待确认。
- `flag`（数字）业务标记，具体定义待确认。
- `invite_code`（字符串）邀请码。
- `invite_st`（数字）邀请相关状态，具体定义待确认。

### 余额与会员权益

- `balance`（数字）余额字段，币种或单位待确认。
- `energy`（数字）用户能量字段。
- `svip_endtime`（数字）用户层的 SVIP 到期时间字段。
- `vip_endtime`（数字）用户层的 VIP 到期时间字段。
- `rights`（对象）权益信息，子字段见下节。

## 用户权益 user.rights

- `coin`（数字）金币字段。
- `energy`（数字）权益对象中的能量字段。
- `experience`（数字）经验值。
- `ic_list`（字符串数组）权益对象中的标签列表。
- `level`（数字）等级。
- `momeny`（数字）原生字段名，含义和单位待确认。
- `svip_endtime`（数字）权益对象中的 SVIP 到期时间字段。
- `vip_endtime`（数字）权益对象中的 VIP 到期时间字段。
